package com.example.domain.model

data class ChatMessage(
    val id: Long = 0,
    val senderAddress: String,
    val receiverAddress: String,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isFromMe: Boolean,
    val messageType: String = "TEXT",
    val mediaPath: String? = null,
    val fileName: String? = null,
    val fileSize: Long = 0L,
    val status: Int = 1
)
