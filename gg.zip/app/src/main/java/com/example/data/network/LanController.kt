package com.example.data.network

import android.content.Context
import android.net.ConnectivityManager
import android.net.DhcpInfo
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.os.Build
import android.util.Base64
import android.util.Log
import com.example.domain.model.ChatMessage
import com.example.domain.model.ConnectionState
import com.example.domain.model.DeviceDomain
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap

class LanController(private val context: Context) {

    companion object {
        private const val TAG = "LanController"
        private const val SERVICE_TYPE = "_waselchat._tcp."
        const val SERVER_PORT = 8888
        private const val UDP_PORT = 9876
    }

    private val scope = CoroutineScope(Dispatchers.IO + Job())

    private val _discoveredDevices = MutableStateFlow<List<DeviceDomain>>(emptyList())
    val discoveredDevices: StateFlow<List<DeviceDomain>> = _discoveredDevices.asStateFlow()

    private val deviceMap = ConcurrentHashMap<String, DeviceDomain>()
    private val deviceLock = Any()

    private fun syncUpdateDevices(
        action: (MutableMap<String, DeviceDomain>) -> Unit
    ) {
        synchronized(deviceLock) {
            action(deviceMap)
            val sortedList = deviceMap.values.sortedWith(
                compareByDescending<DeviceDomain> { it.isConnected }
                    .thenBy { it.name.lowercase() }
                    .thenBy { it.address }
            )
            val currentList = _discoveredDevices.value
            if (hasVisibleChanges(currentList, sortedList)) {
                _discoveredDevices.value = sortedList
            }
        }
    }

    private fun hasVisibleChanges(oldList: List<DeviceDomain>, newList: List<DeviceDomain>): Boolean {
        if (oldList.size != newList.size) return true
        for (i in oldList.indices) {
            val oldDev = oldList[i]
            val newDev = newList[i]
            if (oldDev.address != newDev.address ||
                oldDev.name != newDev.name ||
                oldDev.port != newDev.port ||
                oldDev.isConnected != newDev.isConnected ||
                oldDev.isOnline != newDev.isOnline
            ) {
                return true
            }
        }
        return false
    }

    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val _incomingMessages = MutableSharedFlow<ChatMessage>()
    val incomingMessages: SharedFlow<ChatMessage> = _incomingMessages.asSharedFlow()

    private val _incomingAckEvents = MutableSharedFlow<Long>()
    val incomingAckEvents: SharedFlow<Long> = _incomingAckEvents.asSharedFlow()

    private val _events = MutableSharedFlow<String>()
    val events: SharedFlow<String> = _events.asSharedFlow()

    private val _isWifiConnected = MutableStateFlow(false)
    val isWifiConnected: StateFlow<Boolean> = _isWifiConnected.asStateFlow()

    private val _incomingConnectionRequest = MutableStateFlow<com.example.domain.model.ConnectionRequest?>(null)
    val incomingConnectionRequest: StateFlow<com.example.domain.model.ConnectionRequest?> = _incomingConnectionRequest.asStateFlow()

    private val _outgoingConnectionRequest = MutableStateFlow<DeviceDomain?>(null)
    val outgoingConnectionRequest: StateFlow<DeviceDomain?> = _outgoingConnectionRequest.asStateFlow()

    private val _openChatEvents = MutableSharedFlow<DeviceDomain>()
    val openChatEvents: SharedFlow<DeviceDomain> = _openChatEvents.asSharedFlow()

    private val _fileProgress = MutableStateFlow<Map<Long, Float>>(emptyMap())
    val fileProgress: StateFlow<Map<Long, Float>> = _fileProgress.asStateFlow()

    private data class IncomingTransfer(
        val messageId: Long,
        val senderAddress: String,
        val fileName: String,
        val fileSize: Long,
        val fileType: String,
        val tempFile: File,
        var bytesReceived: Long,
        val outputStream: FileOutputStream
    )
    private val activeTransfers = ConcurrentHashMap<Long, IncomingTransfer>()

    fun updateProgress(messageId: Long, progress: Float) {
        _fileProgress.update { current ->
            val newMap = current.toMutableMap()
            if (progress >= 1.0f) {
                newMap.remove(messageId)
            } else {
                newMap[messageId] = progress
            }
            newMap
        }
    }

    private var outgoingRequestJob: Job? = null
    private var incomingRequestJob: Job? = null

    private var serverSocket: ServerSocket? = null
    private val socketMap = ConcurrentHashMap<String, Socket>()
    private val writerMap = ConcurrentHashMap<String, PrintWriter>()

    private var nsdManager: NsdManager? = null
    private var registrationListener: NsdManager.RegistrationListener? = null
    private var discoveryListener: NsdManager.DiscoveryListener? = null

    private var udpSocket: DatagramSocket? = null
    private var multicastLock: WifiManager.MulticastLock? = null
    private var wifiLock: WifiManager.WifiLock? = null

    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    val myDeviceName: String by lazy {
        val model = Build.MODEL
        if (model.isNotBlank()) "هاتف $model" else "جهاز واصل"
    }

    val voiceCallManager: VoiceCallManager by lazy {
        VoiceCallManager(context) { targetAddress, type, audioPort ->
            sendCallSignalingPacket(targetAddress, type, audioPort)
        }
    }

    init {
        setupNetworkMonitoring()
        startLanServices()
    }

    fun myAddress(): String {
        return getLocalIpAddress() ?: "127.0.0.1"
    }

    private fun setupNetworkMonitoring() {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return

        val networkRequest = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .addTransportType(NetworkCapabilities.TRANSPORT_ETHERNET)
            .build()

        networkCallback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                Log.d(TAG, "Network available")
                scope.launch {
                    delay(200)
                    val ip = getLocalIpAddress()
                    if (ip != null) {
                        _isWifiConnected.value = true
                        sendImmediateUdpPing()
                    }
                }
            }

            override fun onLost(network: Network) {
                Log.d(TAG, "Network lost")
                scope.launch {
                    handleNetworkLost()
                }
            }

            override fun onCapabilitiesChanged(network: Network, networkCapabilities: NetworkCapabilities) {
                val hasLan = networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
                        networkCapabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
                val ip = getLocalIpAddress()
                if (hasLan && ip != null) {
                    if (!_isWifiConnected.value) {
                        _isWifiConnected.value = true
                        scope.launch { sendImmediateUdpPing() }
                    }
                } else {
                    if (_isWifiConnected.value) {
                        scope.launch { handleNetworkLost() }
                    }
                }
            }
        }

        try {
            connectivityManager.registerNetworkCallback(networkRequest, networkCallback!!)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to register network callback: ${e.message}")
        }
    }

    private suspend fun handleNetworkLost() {
        _isWifiConnected.value = false
        sendUdpBye()

        synchronized(deviceLock) {
            deviceMap.clear()
            _discoveredDevices.value = emptyList()
        }

        _outgoingConnectionRequest.value = null
        _incomingConnectionRequest.value = null

        val currState = _connectionState.value
        if (currState is ConnectionState.Connected || currState is ConnectionState.Connecting) {
            _connectionState.value = ConnectionState.Disconnected
            _events.emit("تم انقطاع الاتصال بالشبكة المحلية.")
        }

        try {
            voiceCallManager.endCall()
        } catch (_: Exception) {}

        closeAllSockets()
    }

    fun startLanServices() {
        val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        try {
            if (multicastLock == null) {
                multicastLock = wifiManager?.createMulticastLock("WaselMulticastLock")?.apply {
                    setReferenceCounted(false)
                }
            }
            multicastLock?.let {
                if (!it.isHeld) it.acquire()
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to acquire multicast lock: ${e.message}")
        }

        try {
            if (wifiLock == null) {
                val lockMode = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.Q) {
                    WifiManager.WIFI_MODE_FULL_LOW_LATENCY
                } else {
                    @Suppress("DEPRECATION")
                    WifiManager.WIFI_MODE_FULL_HIGH_PERF
                }
                wifiLock = wifiManager?.createWifiLock(lockMode, "WaselWifiLock")?.apply {
                    setReferenceCounted(false)
                }
            }
            wifiLock?.let {
                if (!it.isHeld) {
                    try {
                        it.acquire()
                    } catch (e: Throwable) {
                        Log.w(TAG, "WifiLock acquire not permitted or failed: ${e.message}")
                    }
                }
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to create/acquire wifi lock: ${e.message}")
        }

        startServerSocket()
        setupNsd()
        startUdpPresenceBroadcaster()
        startUdpPresenceListener()
        startDeviceCleanupTask()
    }

    fun getLocalIpAddress(): String? {
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val networkInterface = interfaces.nextElement()
                if (networkInterface.isLoopback || !networkInterface.isUp) continue
                val addresses = networkInterface.inetAddresses
                while (addresses.hasMoreElements()) {
                    val address = addresses.nextElement()
                    if (!address.isLoopbackAddress && address is java.net.Inet4Address) {
                        val hostAddress = address.hostAddress
                        if (hostAddress != null && hostAddress != "127.0.0.1") {
                            _isWifiConnected.value = true
                            return hostAddress
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error getting IP: ${e.message}")
        }
        _isWifiConnected.value = false
        return null
    }

    private fun startServerSocket() {
        scope.launch {
            try {
                serverSocket = ServerSocket(SERVER_PORT)
                Log.d(TAG, "Server socket opened on port $SERVER_PORT")
                while (isActive) {
                    val socket = serverSocket?.accept() ?: break
                    val remoteIp = socket.inetAddress.hostAddress ?: ""
                    Log.d(TAG, "Incoming connection from $remoteIp")
                    handleIncomingSocket(socket, remoteIp)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Server socket error: ${e.message}")
            }
        }
    }

    private fun setupNsd() {
        nsdManager = context.getSystemService(Context.NSD_SERVICE) as? NsdManager

        val myIp = getLocalIpAddress() ?: return

        val serviceInfo = NsdServiceInfo().apply {
            serviceName = "Wasel_${Build.MODEL}_${myIp.replace(".", "_")}"
            serviceType = SERVICE_TYPE
            port = SERVER_PORT
        }

        registrationListener = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(NsdServiceInfo: NsdServiceInfo) {
                Log.d(TAG, "NSD Service registered: ${NsdServiceInfo.serviceName}")
            }
            override fun onRegistrationFailed(arg0: NsdServiceInfo, arg1: Int) {
                Log.e(TAG, "NSD Registration failed: $arg1")
            }
            override fun onServiceUnregistered(arg0: NsdServiceInfo) {}
            override fun onUnregistrationFailed(arg0: NsdServiceInfo, arg1: Int) {}
        }

        try {
            nsdManager?.registerService(serviceInfo, NsdManager.PROTOCOL_DNS_SD, registrationListener)
        } catch (e: Exception) {
            Log.e(TAG, "NSD register error: ${e.message}")
        }

        discoveryListener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(regType: String) {
                Log.d(TAG, "NSD Discovery started")
            }

            override fun onServiceFound(service: NsdServiceInfo) {
                if (service.serviceType == SERVICE_TYPE || service.serviceType.startsWith("_waselchat")) {
                    nsdManager?.resolveService(service, object : NsdManager.ResolveListener {
                        override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                            Log.e(TAG, "Resolve failed: $errorCode")
                        }

                        override fun onServiceResolved(serviceInfo: NsdServiceInfo) {
                            val host = serviceInfo.host?.hostAddress ?: return
                            val myLocalIp = getLocalIpAddress()
                            if (host == myLocalIp || host == "127.0.0.1") return

                            var name = serviceInfo.serviceName
                            if (name.startsWith("Wasel_")) {
                                val parts = name.split("_")
                                if (parts.size >= 2) name = "هاتف ${parts[1]}"
                            }

                            val device = DeviceDomain(
                                name = name,
                                address = host,
                                port = serviceInfo.port,
                                isOnline = true,
                                lastSeen = System.currentTimeMillis()
                            )
                            addOrUpdateDevice(device)
                        }
                    })
                }
            }

            override fun onServiceLost(service: NsdServiceInfo) {
                Log.d(TAG, "NSD Service lost: ${service.serviceName}")
                val host = service.host?.hostAddress
                if (host != null) {
                    syncUpdateDevices { map ->
                        map.remove(host)
                    }
                }
            }

            override fun onDiscoveryStopped(serviceType: String) {}
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {}
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
        }

        try {
            nsdManager?.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, discoveryListener)
        } catch (e: Exception) {
            Log.e(TAG, "NSD discover error: ${e.message}")
        }
    }

    private fun startUdpPresenceBroadcaster() {
        scope.launch {
            while (isActive) {
                try {
                    val myIp = getLocalIpAddress()
                    if (myIp != null) {
                        _isWifiConnected.value = true
                        val message = "WASEL_PING|$myDeviceName|$myIp|$SERVER_PORT"
                        val data = message.toByteArray()

                        val broadcastAddr = getBroadcastAddress() ?: InetAddress.getByName("255.255.255.255")
                        val socket = DatagramSocket()
                        socket.broadcast = true
                        val packet = DatagramPacket(data, data.size, broadcastAddr, UDP_PORT)
                        socket.send(packet)
                        socket.close()
                    } else {
                        if (_isWifiConnected.value) {
                            handleNetworkLost()
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "UDP broadcast error: ${e.message}")
                }
                delay(800)
            }
        }
    }

    private fun sendImmediateUdpPing() {
        scope.launch(Dispatchers.IO) {
            try {
                val myIp = getLocalIpAddress() ?: return@launch
                val message = "WASEL_PING|$myDeviceName|$myIp|$SERVER_PORT"
                val data = message.toByteArray()
                val broadcastAddr = getBroadcastAddress() ?: InetAddress.getByName("255.255.255.255")
                val socket = DatagramSocket()
                socket.broadcast = true
                val packet = DatagramPacket(data, data.size, broadcastAddr, UDP_PORT)
                socket.send(packet)
                socket.close()
            } catch (e: Exception) {
                Log.e(TAG, "Immediate UDP ping error: ${e.message}")
            }
        }
    }

    private fun sendUdpBye() {
        try {
            val myIp = getLocalIpAddress() ?: "127.0.0.1"
            val message = "WASEL_BYE|$myIp"
            val data = message.toByteArray()
            val broadcastAddr = getBroadcastAddress() ?: InetAddress.getByName("255.255.255.255")
            val socket = DatagramSocket()
            socket.broadcast = true
            val packet = DatagramPacket(data, data.size, broadcastAddr, UDP_PORT)
            socket.send(packet)
            socket.close()
        } catch (_: Exception) {}
    }

    private fun startUdpPresenceListener() {
        scope.launch {
            try {
                udpSocket = DatagramSocket(UDP_PORT)
                val buffer = ByteArray(1024)
                while (isActive) {
                    val packet = DatagramPacket(buffer, buffer.size)
                    udpSocket?.receive(packet)
                    val rawStr = String(packet.data, 0, packet.length).trim()
                    val senderIp = packet.address?.hostAddress ?: ""
                    val myIp = getLocalIpAddress()

                    if (senderIp.isNotEmpty() && senderIp != myIp && senderIp != "127.0.0.1") {
                        if (rawStr.startsWith("WASEL_PING")) {
                            val parts = rawStr.split("|")
                            val devName = if (parts.size > 1) parts[1] else "جهاز $senderIp"
                            val port = if (parts.size > 3) parts[3].toIntOrNull() ?: SERVER_PORT else SERVER_PORT

                            val device = DeviceDomain(
                                name = devName,
                                address = senderIp,
                                port = port,
                                isOnline = true,
                                lastSeen = System.currentTimeMillis()
                            )
                            addOrUpdateDevice(device)

                            sendDirectUdpPong(packet.address, devName)
                        } else if (rawStr.startsWith("WASEL_PONG")) {
                            val parts = rawStr.split("|")
                            val devName = if (parts.size > 1) parts[1] else "جهاز $senderIp"
                            val port = if (parts.size > 3) parts[3].toIntOrNull() ?: SERVER_PORT else SERVER_PORT

                            val device = DeviceDomain(
                                name = devName,
                                address = senderIp,
                                port = port,
                                isOnline = true,
                                lastSeen = System.currentTimeMillis()
                            )
                            addOrUpdateDevice(device)
                        } else if (rawStr.startsWith("WASEL_BYE")) {
                            removeDeviceImmediately(senderIp)
                        } else if (rawStr.startsWith("{")) {
                            processIncomingJson(rawStr, senderIp)
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "UDP listener error: ${e.message}")
            }
        }
    }

    private fun sendDirectUdpPong(targetAddr: InetAddress, targetName: String) {
        scope.launch(Dispatchers.IO) {
            try {
                val myIp = getLocalIpAddress() ?: return@launch
                val message = "WASEL_PONG|$myDeviceName|$myIp|$SERVER_PORT"
                val data = message.toByteArray()
                val socket = DatagramSocket()
                val packet = DatagramPacket(data, data.size, targetAddr, UDP_PORT)
                socket.send(packet)
                socket.close()
            } catch (_: Exception) {}
        }
    }

    private fun getBroadcastAddress(): InetAddress? {
        return try {
            val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            val dhcp: DhcpInfo = wifiManager?.dhcpInfo ?: return null
            val broadcast = (dhcp.ipAddress and dhcp.netmask) or dhcp.netmask.inv()
            val quads = ByteArray(4)
            for (k in 0..3) {
                quads[k] = ((broadcast shr (k * 8)) and 0xFF).toByte()
            }
            InetAddress.getByAddress(quads)
        } catch (e: Exception) {
            null
        }
    }

    private fun addOrUpdateDevice(device: DeviceDomain) {
        if (!_isWifiConnected.value) return
        syncUpdateDevices { map ->
            val existing = map[device.address]
            val isSocketActive = socketMap[device.address]?.run { isConnected && !isClosed } ?: false
            val resolvedName = when {
                device.name.isNotBlank() && !device.name.startsWith("جهاز 192") -> device.name
                existing != null && existing.name.isNotBlank() && !existing.name.startsWith("جهاز 192") -> existing.name
                else -> device.name
            }
            val updated = DeviceDomain(
                name = resolvedName,
                address = device.address,
                port = device.port,
                isConnected = isSocketActive || device.isConnected || (existing?.isConnected == true),
                isOnline = true,
                lastSeen = System.currentTimeMillis()
            )
            map[device.address] = updated
        }
    }

    private fun removeDeviceImmediately(ip: String) {
        closeSocketForAddress(ip)
        syncUpdateDevices { map ->
            map.remove(ip)
        }
    }

    private fun startDeviceCleanupTask() {
        scope.launch {
            while (isActive) {
                delay(1000)
                if (!_isWifiConnected.value) continue

                val now = System.currentTimeMillis()
                val toRemove = mutableListOf<String>()

                synchronized(deviceLock) {
                    for ((ip, dev) in deviceMap) {
                        if (now - dev.lastSeen > 12000L) {
                            toRemove.add(ip)
                        }
                    }
                }

                for (ip in toRemove) {
                    val dev = deviceMap[ip]
                    if (dev != null) {
                        val currentConn = _connectionState.value
                        if (currentConn is ConnectionState.Connected && currentConn.device.address == dev.address) {
                            _connectionState.value = ConnectionState.Disconnected
                            _events.emit("انقطع الاتصال مع ${dev.name}")
                        }
                        closeSocketForAddress(dev.address)
                    }
                    syncUpdateDevices { map ->
                        map.remove(ip)
                    }
                }
            }
        }
    }

    fun requestConnection(device: DeviceDomain) {
        scope.launch {
            if (_outgoingConnectionRequest.value != null) {
                _events.emit("يوجد طلب اتصال قيد الانتظار بالفعل")
                return@launch
            }

            val currState = _connectionState.value
            if (currState is ConnectionState.Connected && currState.device.address == device.address) {
                _openChatEvents.emit(device)
                return@launch
            }

            _outgoingConnectionRequest.value = device
            _connectionState.value = ConnectionState.Connecting(device)

            var socketConnected = socketMap[device.address]?.let { it.isConnected && !it.isClosed } ?: false
            if (!socketConnected) {
                socketConnected = connectSocketInternal(device.address)
            }

            if (!socketConnected) {
                _outgoingConnectionRequest.value = null
                _connectionState.value = ConnectionState.Disconnected
                removeDeviceImmediately(device.address)
                _events.emit("تعذر فتح قناة الاتصال بالجهاز ${device.name}")
                return@launch
            }

            val sent = sendConnectionRequestPacket(device.address)
            if (!sent) {
                _outgoingConnectionRequest.value = null
                _connectionState.value = ConnectionState.Disconnected
                removeDeviceImmediately(device.address)
                _events.emit("فشل إرسال طلب الاتصال")
                return@launch
            }

            outgoingRequestJob?.cancel()
            outgoingRequestJob = scope.launch {
                delay(30000)
                if (_outgoingConnectionRequest.value?.address == device.address) {
                    sendConnectionResponsePacket(device.address, "CONNECT_CANCEL")
                    _outgoingConnectionRequest.value = null
                    _connectionState.value = ConnectionState.Disconnected
                    _events.emit("تم إلغاء طلب الاتصال بسبب عدم الرد.")
                }
            }
        }
    }

    fun acceptConnectionRequest() {
        val req = _incomingConnectionRequest.value ?: return
        incomingRequestJob?.cancel()
        _incomingConnectionRequest.value = null

        val dev = deviceMap[req.senderAddress] ?: DeviceDomain(
            name = req.senderName,
            address = req.senderAddress,
            port = SERVER_PORT,
            isOnline = true
        )

        scope.launch {
            sendConnectionResponsePacket(req.senderAddress, "CONNECT_ACCEPT")
            val connectedDev = dev.copy(isConnected = true, isOnline = true)
            _connectionState.value = ConnectionState.Connected(connectedDev)
            addOrUpdateDevice(connectedDev)
            _openChatEvents.emit(connectedDev)
        }
    }

    fun rejectConnectionRequest() {
        val req = _incomingConnectionRequest.value ?: return
        incomingRequestJob?.cancel()
        _incomingConnectionRequest.value = null

        scope.launch {
            sendConnectionResponsePacket(req.senderAddress, "CONNECT_REJECT")
        }
    }

    fun cancelOutgoingConnectionRequest() {
        val dev = _outgoingConnectionRequest.value ?: return
        outgoingRequestJob?.cancel()
        _outgoingConnectionRequest.value = null
        _connectionState.value = ConnectionState.Disconnected

        scope.launch {
            sendConnectionResponsePacket(dev.address, "CONNECT_CANCEL")
            _events.emit("تم إلغاء طلب الاتصال.")
        }
    }

    fun connectToDevice(device: DeviceDomain) {
        requestConnection(device)
    }

    private suspend fun connectSocketInternal(targetAddress: String): Boolean = withContext(Dispatchers.IO) {
        try {
            closeSocketForAddress(targetAddress)
            val socket = Socket()
            socket.connect(java.net.InetSocketAddress(targetAddress, SERVER_PORT), 2500)
            val writer = PrintWriter(socket.getOutputStream(), true)

            socketMap[targetAddress] = socket
            writerMap[targetAddress] = writer

            val handshakeObj = JSONObject().apply {
                put("type", "HANDSHAKE")
                put("deviceName", myDeviceName)
                put("senderAddress", myAddress())
            }
            writer.println(handshakeObj.toString())
            writer.flush()

            val dev = deviceMap[targetAddress] ?: DeviceDomain(
                name = "جهاز $targetAddress",
                address = targetAddress,
                port = SERVER_PORT,
                isOnline = true
            )
            addOrUpdateDevice(dev.copy(isOnline = true))

            scope.launch {
                listenToSocket(socket, targetAddress)
            }

            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed connectSocketInternal to $targetAddress: ${e.message}")
            closeSocketForAddress(targetAddress)
            false
        }
    }

    private fun handleIncomingSocket(socket: Socket, remoteIp: String) {
        scope.launch {
            val remoteDevice = (deviceMap[remoteIp] ?: DeviceDomain(
                name = "جهاز $remoteIp",
                address = remoteIp,
                port = SERVER_PORT,
                isOnline = true
            )).copy(isOnline = true)

            closeSocketForAddress(remoteIp)
            socketMap[remoteIp] = socket
            writerMap[remoteIp] = PrintWriter(socket.getOutputStream(), true)

            addOrUpdateDevice(remoteDevice)

            listenToSocket(socket, remoteIp)
        }
    }

    private suspend fun listenToSocket(socket: Socket, remoteIp: String) {
        withContext(Dispatchers.IO) {
            try {
                val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
                while (isActive && !socket.isClosed) {
                    val line = reader.readLine() ?: break
                    if (line.isNotBlank()) {
                        processIncomingJson(line, remoteIp)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Socket read error from $remoteIp: ${e.message}")
            } finally {
                closeSocketForAddress(remoteIp)
            }
        }
    }

    private fun processIncomingJson(jsonStr: String, senderIp: String) {
        try {
            val json = JSONObject(jsonStr)
            val type = json.optString("type")
            val senderName = json.optString("senderName", "")
            val senderAddress = json.optString("senderAddress", senderIp)

            val device = DeviceDomain(
                name = senderName.ifEmpty { "جهاز $senderAddress" },
                address = senderAddress,
                port = SERVER_PORT,
                isOnline = true,
                lastSeen = System.currentTimeMillis()
            )
            addOrUpdateDevice(device)

            when (type) {
                "HANDSHAKE" -> {
                    Log.d(TAG, "Handshake received from ${device.name}")
                }

                "CONNECT_REQUEST" -> {
                    val devName = senderName.ifEmpty { "جهاز $senderAddress" }
                    if (_incomingConnectionRequest.value != null || _connectionState.value is ConnectionState.Connected) {
                        scope.launch {
                            sendConnectionResponsePacket(senderAddress, "CONNECT_REJECT")
                        }
                    } else {
                        val req = com.example.domain.model.ConnectionRequest(
                            senderName = devName,
                            senderAddress = senderAddress
                        )
                        _incomingConnectionRequest.value = req

                        incomingRequestJob?.cancel()
                        incomingRequestJob = scope.launch {
                            delay(30000)
                            if (_incomingConnectionRequest.value?.senderAddress == senderAddress) {
                                _incomingConnectionRequest.value = null
                            }
                        }
                    }
                }

                "CONNECT_ACCEPT" -> {
                    outgoingRequestJob?.cancel()
                    _outgoingConnectionRequest.value = null

                    val dev = deviceMap[senderAddress] ?: DeviceDomain(
                        name = senderName.ifEmpty { "جهاز $senderAddress" },
                        address = senderAddress,
                        port = SERVER_PORT,
                        isOnline = true
                    )
                    val connectedDev = dev.copy(isConnected = true, isOnline = true)
                    _connectionState.value = ConnectionState.Connected(connectedDev)
                    addOrUpdateDevice(connectedDev)
                    scope.launch {
                        _openChatEvents.emit(connectedDev)
                    }
                }

                "CONNECT_REJECT" -> {
                    outgoingRequestJob?.cancel()
                    _outgoingConnectionRequest.value = null
                    _connectionState.value = ConnectionState.Disconnected
                    scope.launch {
                        _events.emit("تم رفض طلب الاتصال.")
                    }
                }

                "CONNECT_CANCEL" -> {
                    incomingRequestJob?.cancel()
                    if (_incomingConnectionRequest.value?.senderAddress == senderAddress) {
                        _incomingConnectionRequest.value = null
                    }
                }

                "TEXT", "IMAGE", "VIDEO", "FILE", "AUDIO" -> {
                    val msgId = json.optLong("messageId", System.currentTimeMillis())
                    val text = json.optString("text", "")
                    val fileName = json.optString("fileName", "")
                    val fileSize = json.optLong("fileSize", 0L)
                    val mediaBase64 = json.optString("mediaBase64", "")

                    var localFilePath: String? = null
                    if (mediaBase64.isNotEmpty() && fileName.isNotEmpty()) {
                        localFilePath = saveMediaToDisk(mediaBase64, fileName)
                    }

                    val msg = ChatMessage(
                        id = msgId,
                        senderAddress = senderAddress,
                        receiverAddress = myAddress(),
                        text = text,
                        timestamp = System.currentTimeMillis(),
                        isFromMe = false,
                        messageType = type,
                        mediaPath = localFilePath,
                        fileName = fileName,
                        fileSize = fileSize,
                        status = 1
                    )

                    sendAckPacket(senderAddress, msgId)

                    scope.launch {
                        _incomingMessages.emit(msg)
                    }

                    val typeDesc = when (type) {
                        "TEXT" -> text
                        "IMAGE" -> "صورة جديدة 🖼️"
                        "VIDEO" -> "فيديو جديد 🎥"
                        "AUDIO" -> "رسالة صوتية 🎙️"
                        else -> "ملف جديد: $fileName"
                    }

                    LanService.showMessageNotification(
                        context = context,
                        deviceName = senderName.ifEmpty { "جهاز $senderAddress" },
                        deviceAddress = senderAddress,
                        text = typeDesc
                    )
                }

                "FILE_START" -> {
                    val msgId = json.optLong("messageId", System.currentTimeMillis())
                    val fileName = json.optString("fileName", "file_$msgId")
                    val fileSize = json.optLong("fileSize", 0L)
                    val fileType = json.optString("fileType", "FILE")

                    val dir = File(context.filesDir, "wasel_received_files")
                    if (!dir.exists()) dir.mkdirs()
                    val tempFile = File(dir, "temp_${msgId}_$fileName")
                    val fos = FileOutputStream(tempFile)

                    val transfer = IncomingTransfer(
                        messageId = msgId,
                        senderAddress = senderAddress,
                        fileName = fileName,
                        fileSize = fileSize,
                        fileType = fileType,
                        tempFile = tempFile,
                        bytesReceived = 0L,
                        outputStream = fos
                    )
                    activeTransfers[msgId] = transfer
                    updateProgress(msgId, 0.0f)

                    val initialMsg = ChatMessage(
                        id = msgId,
                        senderAddress = senderAddress,
                        receiverAddress = myAddress(),
                        text = if (fileType == "IMAGE") "صورة" else if (fileType == "VIDEO") "فيديو" else fileName,
                        timestamp = System.currentTimeMillis(),
                        isFromMe = false,
                        messageType = fileType,
                        mediaPath = tempFile.absolutePath,
                        fileName = fileName,
                        fileSize = fileSize,
                        status = 2
                    )

                    scope.launch {
                        _incomingMessages.emit(initialMsg)
                    }
                }

                "FILE_CHUNK" -> {
                    val msgId = json.optLong("messageId", -1L)
                    val base64Chunk = json.optString("data", "")
                    val transfer = activeTransfers[msgId]
                    if (transfer != null && base64Chunk.isNotEmpty()) {
                        try {
                            val bytes = Base64.decode(base64Chunk, Base64.NO_WRAP)
                            transfer.outputStream.write(bytes)
                            transfer.bytesReceived += bytes.size
                            val progress = if (transfer.fileSize > 0) {
                                (transfer.bytesReceived.toFloat() / transfer.fileSize.toFloat()).coerceIn(0f, 0.99f)
                            } else 0.5f
                            updateProgress(msgId, progress)
                        } catch (e: Exception) {
                            Log.e(TAG, "Error writing chunk: ${e.message}")
                        }
                    }
                }

                "FILE_END" -> {
                    val msgId = json.optLong("messageId", -1L)
                    val transfer = activeTransfers.remove(msgId)
                    if (transfer != null) {
                        try {
                            transfer.outputStream.flush()
                            transfer.outputStream.close()
                        } catch (_: Exception) {}

                        val dir = File(context.filesDir, "wasel_received_files")
                        val finalFile = File(dir, "received_${msgId}_${transfer.fileName}")
                        if (transfer.tempFile.exists()) {
                            transfer.tempFile.renameTo(finalFile)
                        }

                        updateProgress(msgId, 1.0f)

                        val completedMsg = ChatMessage(
                            id = msgId,
                            senderAddress = transfer.senderAddress,
                            receiverAddress = myAddress(),
                            text = if (transfer.fileType == "IMAGE") "صورة" else if (transfer.fileType == "VIDEO") "فيديو" else transfer.fileName,
                            timestamp = System.currentTimeMillis(),
                            isFromMe = false,
                            messageType = transfer.fileType,
                            mediaPath = finalFile.absolutePath,
                            fileName = transfer.fileName,
                            fileSize = transfer.fileSize,
                            status = 1
                        )

                        sendAckPacket(transfer.senderAddress, msgId)

                        scope.launch {
                            _incomingMessages.emit(completedMsg)
                        }

                        val typeDesc = when (transfer.fileType) {
                            "IMAGE" -> "صورة جديدة 🖼️"
                            "VIDEO" -> "فيديو جديد 🎥"
                            else -> "ملف جديد: ${transfer.fileName}"
                        }

                        LanService.showMessageNotification(
                            context = context,
                            deviceName = senderName.ifEmpty { "جهاز $senderAddress" },
                            deviceAddress = senderAddress,
                            text = typeDesc
                        )
                    }
                }

                "ACK" -> {
                    val ackMsgId = json.optLong("messageId", -1L)
                    if (ackMsgId != -1L) {
                        scope.launch {
                            _incomingAckEvents.emit(ackMsgId)
                        }
                    }
                }

                "CALL_REQUEST", "CALL_OFFER" -> {
                    val audioPort = json.optInt("audioPort", VoiceCallManager.DEFAULT_AUDIO_PORT)
                    val callerName = senderName.ifEmpty { "جهاز $senderAddress" }
                    voiceCallManager.onIncomingCallOffer(callerName, senderAddress, audioPort)
                }

                "CALL_ACCEPT" -> {
                    LanService.cancelCallNotification(context)
                    val audioPort = json.optInt("audioPort", VoiceCallManager.DEFAULT_AUDIO_PORT)
                    voiceCallManager.onCallAccepted(senderAddress, audioPort)
                }

                "CALL_REJECT" -> {
                    LanService.cancelCallNotification(context)
                    voiceCallManager.onCallRejected()
                }

                "CALL_BUSY" -> {
                    LanService.cancelCallNotification(context)
                    voiceCallManager.onCallBusy()
                }

                "CALL_END" -> {
                    LanService.cancelCallNotification(context)
                    voiceCallManager.onCallEndedByPeer()
                }

                "CALL_HEARTBEAT" -> {
                    voiceCallManager.onHeartbeatReceived(senderAddress)
                }

                "AVAILABLE" -> {
                    Log.d(TAG, "Device $senderAddress is now AVAILABLE")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing incoming JSON: ${e.message}")
        }
    }

    private fun sendUdpSignalingPacket(targetAddress: String, type: String, audioPort: Int): Boolean {
        return try {
            val targetAddr = InetAddress.getByName(targetAddress)
            val json = JSONObject().apply {
                put("type", type)
                put("senderAddress", myAddress())
                put("senderName", myDeviceName)
                put("audioPort", audioPort)
            }
            val data = json.toString().toByteArray()
            val socket = DatagramSocket()
            val packet = DatagramPacket(data, data.size, targetAddr, UDP_PORT)
            socket.send(packet)
            socket.close()
            true
        } catch (e: Exception) {
            Log.e(TAG, "sendUdpSignalingPacket error: ${e.message}")
            false
        }
    }

    private suspend fun sendConnectionRequestPacket(targetAddress: String): Boolean =
        sendConnectionResponsePacket(targetAddress, "CONNECT_REQUEST")

    private suspend fun sendConnectionResponsePacket(targetAddress: String, type: String): Boolean = withContext(Dispatchers.IO) {
        try {
            var writer = writerMap[targetAddress]
            var socket = socketMap[targetAddress]

            if (socket == null || socket.isClosed || !socket.isConnected || writer == null) {
                val connected = connectSocketInternal(targetAddress)
                if (!connected) return@withContext false
                writer = writerMap[targetAddress]
            }

            if (writer == null) return@withContext false

            val json = JSONObject().apply {
                put("type", type)
                put("senderAddress", myAddress())
                put("senderName", myDeviceName)
            }
            writer.println(json.toString())
            writer.flush()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error sending $type packet to $targetAddress: ${e.message}")
            false
        }
    }

    suspend fun sendCallSignalingPacket(
        targetAddress: String,
        type: String,
        audioPort: Int
    ): Boolean {
        return withContext(Dispatchers.IO) {
            var tcpSuccess = false
            try {
                var writer = writerMap[targetAddress]
                var socket = socketMap[targetAddress]

                if (socket == null || socket.isClosed || !socket.isConnected || writer == null) {
                    if (connectSocketInternal(targetAddress)) {
                        writer = writerMap[targetAddress]
                    }
                }

                if (writer != null) {
                    val json = JSONObject().apply {
                        put("type", type)
                        put("senderAddress", myAddress())
                        put("senderName", myDeviceName)
                        put("audioPort", audioPort)
                    }
                    writer.println(json.toString())
                    writer.flush()
                    tcpSuccess = true
                }
            } catch (e: Exception) {
                Log.e(TAG, "Send call signaling packet error to $targetAddress: ${e.message}")
                closeSocketForAddress(targetAddress)
            }

            // Always attempt UDP signaling packet as well for maximum reliability across LAN
            val udpSuccess = sendUdpSignalingPacket(targetAddress, type, audioPort)
            tcpSuccess || udpSuccess
        }
    }

    suspend fun sendMessagePacket(
        targetAddress: String,
        type: String,
        messageId: Long,
        text: String,
        fileName: String? = null,
        fileSize: Long = 0L,
        mediaBase64: String? = null
    ): Boolean {
        return withContext(Dispatchers.IO) {
            try {
                var writer = writerMap[targetAddress]
                var socket = socketMap[targetAddress]

                if (socket == null || socket.isClosed || !socket.isConnected || writer == null) {
                    val connected = connectSocketInternal(targetAddress)
                    if (!connected) return@withContext false
                    writer = writerMap[targetAddress]
                }

                if (writer == null) return@withContext false

                val json = JSONObject().apply {
                    put("type", type)
                    put("messageId", messageId)
                    put("senderAddress", myAddress())
                    put("senderName", myDeviceName)
                    put("text", text)
                    if (fileName != null) put("fileName", fileName)
                    if (fileSize > 0) put("fileSize", fileSize)
                    if (mediaBase64 != null) put("mediaBase64", mediaBase64)
                }
                writer.println(json.toString())
                writer.flush()
                true
            } catch (e: Exception) {
                Log.e(TAG, "Send message packet error to $targetAddress: ${e.message}")
                closeSocketForAddress(targetAddress)
                try {
                    if (connectSocketInternal(targetAddress)) {
                        val retryWriter = writerMap[targetAddress] ?: return@withContext false
                        val json = JSONObject().apply {
                            put("type", type)
                            put("messageId", messageId)
                            put("senderAddress", myAddress())
                            put("senderName", myDeviceName)
                            put("text", text)
                            if (fileName != null) put("fileName", fileName)
                            if (fileSize > 0) put("fileSize", fileSize)
                            if (mediaBase64 != null) put("mediaBase64", mediaBase64)
                        }
                        retryWriter.println(json.toString())
                        retryWriter.flush()
                        return@withContext true
                    }
                } catch (_: Exception) {}
                false
            }
        }
    }

    suspend fun sendFileInChunks(
        targetAddress: String,
        messageId: Long,
        file: File,
        fileName: String,
        fileSize: Long,
        type: String
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            var writer = writerMap[targetAddress]
            var socket = socketMap[targetAddress]

            if (socket == null || socket.isClosed || !socket.isConnected || writer == null) {
                val connected = connectSocketInternal(targetAddress)
                if (!connected) return@withContext false
                writer = writerMap[targetAddress]
            }

            if (writer == null) return@withContext false

            val startJson = JSONObject().apply {
                put("type", "FILE_START")
                put("messageId", messageId)
                put("senderAddress", myAddress())
                put("senderName", myDeviceName)
                put("fileName", fileName)
                put("fileSize", fileSize)
                put("fileType", type)
            }
            writer.println(startJson.toString())
            writer.flush()

            updateProgress(messageId, 0.0f)

            val buffer = ByteArray(64 * 1024)
            var totalSent = 0L

            FileInputStream(file).use { fis ->
                var bytesRead: Int
                var chunkIndex = 0
                while (fis.read(buffer).also { bytesRead = it } != -1) {
                    val chunkBytes = if (bytesRead == buffer.size) buffer else buffer.copyOf(bytesRead)
                    val base64Data = Base64.encodeToString(chunkBytes, Base64.NO_WRAP)

                    val chunkJson = JSONObject().apply {
                        put("type", "FILE_CHUNK")
                        put("messageId", messageId)
                        put("chunkIndex", chunkIndex)
                        put("data", base64Data)
                    }
                    writer.println(chunkJson.toString())
                    writer.flush()

                    totalSent += bytesRead
                    chunkIndex++

                    val progress = if (fileSize > 0) {
                        (totalSent.toFloat() / fileSize.toFloat()).coerceIn(0f, 0.99f)
                    } else 0.5f

                    updateProgress(messageId, progress)
                }
            }

            val endJson = JSONObject().apply {
                put("type", "FILE_END")
                put("messageId", messageId)
                put("senderAddress", myAddress())
            }
            writer.println(endJson.toString())
            writer.flush()

            updateProgress(messageId, 1.0f)
            true
        } catch (e: Exception) {
            Log.e(TAG, "sendFileInChunks error to $targetAddress: ${e.message}")
            closeSocketForAddress(targetAddress)
            updateProgress(messageId, 0f)
            false
        }
    }

    private fun sendAckPacket(targetAddress: String, messageId: Long) {
        try {
            val writer = writerMap[targetAddress] ?: return
            val json = JSONObject().apply {
                put("type", "ACK")
                put("messageId", messageId)
                put("senderAddress", myAddress())
            }
            writer.println(json.toString())
            writer.flush()
        } catch (e: Exception) {
            Log.e(TAG, "Send ACK error: ${e.message}")
        }
    }

    private fun saveMediaToDisk(base64Data: String, fileName: String): String? {
        return try {
            val bytes = Base64.decode(base64Data, Base64.DEFAULT)
            val dir = File(context.filesDir, "wasel_received_files")
            if (!dir.exists()) dir.mkdirs()
            val destFile = File(dir, "${System.currentTimeMillis()}_$fileName")
            FileOutputStream(destFile).use { it.write(bytes) }
            destFile.absolutePath
        } catch (e: Exception) {
            Log.e(TAG, "Save media error: ${e.message}")
            null
        }
    }

    fun closeConnection() {
        scope.launch {
            closeAllSockets()
            _connectionState.value = ConnectionState.Disconnected
        }
    }

    private fun closeAllSockets() {
        for (ip in socketMap.keys) {
            closeSocketForAddress(ip)
        }
    }

    private fun closeSocketForAddress(ip: String) {
        try {
            writerMap.remove(ip)?.close()
            socketMap.remove(ip)?.close()
        } catch (_: Exception) {}

        val currentConn = _connectionState.value
        if (currentConn is ConnectionState.Connected && currentConn.device.address == ip) {
            _connectionState.value = ConnectionState.Disconnected
        }
        if (_outgoingConnectionRequest.value?.address == ip) {
            outgoingRequestJob?.cancel()
            _outgoingConnectionRequest.value = null
        }
        if (_incomingConnectionRequest.value?.senderAddress == ip) {
            incomingRequestJob?.cancel()
            _incomingConnectionRequest.value = null
        }

        syncUpdateDevices { map ->
            val existingDev = map[ip]
            if (existingDev != null) {
                map[ip] = existingDev.copy(isConnected = false)
            }
        }
    }

    fun cleanUp() {
        sendUdpBye()
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        if (networkCallback != null) {
            try {
                connectivityManager?.unregisterNetworkCallback(networkCallback!!)
            } catch (_: Exception) {}
        }
        closeConnection()
        try {
            voiceCallManager.cleanUp()
            serverSocket?.close()
            udpSocket?.close()
            try {
                if (multicastLock?.isHeld == true) {
                    multicastLock?.release()
                }
            } catch (_: Throwable) {}
            try {
                if (wifiLock?.isHeld == true) {
                    wifiLock?.release()
                }
            } catch (_: Throwable) {}
            if (registrationListener != null) {
                nsdManager?.unregisterService(registrationListener)
            }
            if (discoveryListener != null) {
                nsdManager?.stopServiceDiscovery(discoveryListener)
            }
        } catch (_: Exception) {}
    }
}
