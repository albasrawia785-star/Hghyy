package com.example.data.bluetooth

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * خدمة مستمرة للعمل في الخلفية للحفاظ على استقرار اتصال البلوتوث واستقبال البيانات.
 * تستخدم FOREGROUND_SERVICE_CONNECTED_DEVICE لإبقاء الاتصال نشطاً حتى عند إغلاق الشاشة.
 */
class BluetoothForegroundService : Service() {

    companion object {
        private const val TAG = "BluetoothFgService"
        const val CHANNEL_ID = "wasel_bluetooth_fg_channel"
        const val NOTIFICATION_ID = 1002

        const val ACTION_START_SERVICE = "ACTION_START_BLUETOOTH_SERVICE"
        const val ACTION_STOP_SERVICE = "ACTION_STOP_BLUETOOTH_SERVICE"

        fun startService(context: Context) {
            val intent = Intent(context, BluetoothForegroundService::class.java).apply {
                action = ACTION_START_SERVICE
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    try {
                        context.startForegroundService(intent)
                    } catch (e: Throwable) {
                        Log.w(TAG, "Foreground service start postponed until activity is active: ${e.message}")
                    }
                } else {
                    context.startService(intent)
                }
            } catch (e: Throwable) {
                Log.w(TAG, "BluetoothForegroundService start skipped: ${e.message}")
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, BluetoothForegroundService::class.java).apply {
                action = ACTION_STOP_SERVICE
            }
            try {
                context.stopService(intent)
            } catch (e: Throwable) {
                Log.e(TAG, "Error stopping BluetoothForegroundService: ${e.message}")
            }
        }
    }

    private val serviceScope = CoroutineScope(Dispatchers.IO + Job())

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        promoteToForeground()
        startConnectionMonitoring()
    }

    private fun promoteToForeground() {
        try {
            val openIntent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val pendingIntent = PendingIntent.getActivity(
                this,
                0,
                openIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val notification = NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("واصل - اتصال البلوتوث نشط")
                .setContentText("الخدمة تعمل في الخلفية لضمان بقاء اتصال البلوتوث مستقراً واستقبال الرسائل")
                .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOngoing(true)
                .setContentIntent(pendingIntent)
                .build()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val serviceType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
                } else {
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
                }
                startForeground(NOTIFICATION_ID, notification, serviceType)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Throwable) {
            Log.w(TAG, "startForeground failed or disallowed: ${e.message}")
        }
    }

    private fun startConnectionMonitoring() {
        serviceScope.launch {
            while (isActive) {
                delay(15_000L)
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        promoteToForeground()
        if (intent?.action == ACTION_STOP_SERVICE) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        val app = application as? com.example.WaselApplication
        if (app?.notificationSettings?.isPersistentBackgroundEnabled() != false) {
            val restartIntent = Intent(applicationContext, BluetoothForegroundService::class.java).apply {
                action = ACTION_START_SERVICE
            }
            val pendingIntent = android.app.PendingIntent.getService(
                applicationContext,
                1002,
                restartIntent,
                android.app.PendingIntent.FLAG_ONE_SHOT or android.app.PendingIntent.FLAG_IMMUTABLE
            )
            val alarmManager = getSystemService(android.content.Context.ALARM_SERVICE) as? android.app.AlarmManager
            alarmManager?.set(
                android.app.AlarmManager.RTC_WAKEUP,
                System.currentTimeMillis() + 500,
                pendingIntent
            )
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "خدمة البلوتوث المستمرة",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "إشعار تشغيل خدمة البلوتوث في الخلفية لضمان استقرار الاتصال"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
