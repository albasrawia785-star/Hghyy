package com.example.data.network

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.media.Ringtone
import android.media.RingtoneManager
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.media.ToneGenerator
import android.os.Build
import android.os.PowerManager
import android.os.Process
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentSkipListMap
import java.util.concurrent.ArrayBlockingQueue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress

sealed class CallState {
    object Idle : CallState()
    data class OutgoingCalling(val targetName: String, val targetAddress: String) : CallState()
    data class IncomingRinging(val callerName: String, val callerAddress: String, val callerAudioPort: Int) : CallState()
    data class Connecting(val peerName: String, val peerAddress: String, val remoteAudioPort: Int) : CallState()
    data class ActiveCall(
        val peerName: String,
        val peerAddress: String,
        val durationSeconds: Long = 0,
        val isMuted: Boolean = false,
        val isSpeakerOn: Boolean = true
    ) : CallState()
    data class Busy(val reason: String = "الطرف الآخر مشغول بمكالمة أخرى") : CallState()
    data class Rejected(val reason: String = "تم رفض المكالمة") : CallState()
    data class Missed(val reason: String = "مكالمة لم يرد عليها") : CallState()
    data class Ended(val reason: String = "تم إنهاء المكالمة") : CallState()
    data class Failed(val reason: String = "فشل الاتصال") : CallState()
}

val CallState.isInCallOrRinging: Boolean
    get() = this is CallState.OutgoingCalling ||
            this is CallState.IncomingRinging ||
            this is CallState.Connecting ||
            this is CallState.ActiveCall

val CallState.isTerminalState: Boolean
    get() = this is CallState.Busy ||
            this is CallState.Rejected ||
            this is CallState.Missed ||
            this is CallState.Ended ||
            this is CallState.Failed

class VoiceCallManager(
    private val context: Context,
    private val sendSignalingPacket: suspend (targetAddress: String, type: String, audioPort: Int) -> Boolean
) {

    companion object {
        private const val TAG = "VoiceCallManager"
        const val DEFAULT_AUDIO_PORT = 7070
        private const val SAMPLE_RATE = 16000
        private const val CHANNEL_CONFIG_IN = AudioFormat.CHANNEL_IN_MONO
        private const val CHANNEL_CONFIG_OUT = AudioFormat.CHANNEL_OUT_MONO
        private const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
        private const val HEARTBEAT_INTERVAL_MS = 2500L
        private const val HEARTBEAT_TIMEOUT_MS = 7000L

        // Voice Packet Protocol Constants
        private const val MAGIC_HEADER = 0x564F4943 // "VOIC"
        private const val HEADER_SIZE = 16 // 4 bytes Magic + 4 bytes Seq + 8 bytes Timestamp
        private const val FRAME_SIZE_BYTES = 640 // 20ms @ 16kHz mono 16bit PCM
        private const val PACKET_SIZE = HEADER_SIZE + FRAME_SIZE_BYTES
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val stateMutex = Mutex()

    private val _callState = MutableStateFlow<CallState>(CallState.Idle)
    val callState: StateFlow<CallState> = _callState.asStateFlow()

    private val _callEvents = MutableSharedFlow<String>()
    val callEvents: SharedFlow<String> = _callEvents.asSharedFlow()

    // Audio Resources & FX
    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private var audioUdpSocket: DatagramSocket? = null
    private var echoCanceler: AcousticEchoCanceler? = null
    private var gainControl: AutomaticGainControl? = null
    private var noiseSuppressor: NoiseSuppressor? = null

    // Jobs
    private var recordJob: Job? = null
    private var playJob: Job? = null
    private var timerJob: Job? = null
    private var timeoutJob: Job? = null
    private var heartbeatJob: Job? = null
    private var resetToIdleJob: Job? = null
    private var metricsJob: Job? = null

    // VoIP Metrics
    @Volatile private var packetsSent = 0L
    @Volatile private var packetsReceived = 0L
    @Volatile private var packetsDropped = 0L
    @Volatile private var lastCalculatedLatencyMs = 0L

    // Tones and Feedback
    private var ringbackTone: ToneGenerator? = null
    private var incomingRingtone: Ringtone? = null

    // Audio Manager and Hardware Locks
    private val audioManager: AudioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var originalAudioMode: Int = AudioManager.MODE_NORMAL
    private var originalSpeakerState: Boolean = false
    private var wakeLock: PowerManager.WakeLock? = null

    private var isMuted = false
    private var isSpeakerOn = true
    @Volatile
    private var lastPeerActivityTimestamp = 0L

    init {
        // App Start Cleanup: Ensure clean state upon startup or restart
        stopAllCallResources()
        _callState.value = CallState.Idle
        Log.d(TAG, "VoiceCallManager initialized cleanly into IDLE state")
    }

    // --- Single State Machine Transition Logic ---
    private suspend fun transitionTo(newState: CallState, reason: String) {
        stateMutex.withLock {
            val oldState = _callState.value
            if (oldState == newState) return@withLock

            Log.d(
                TAG,
                "CALL STATE TRANSITION: [${oldState::class.simpleName}] ➔ [${newState::class.simpleName}] | Reason: $reason"
            )

            _callState.value = newState

            when (newState) {
                is CallState.OutgoingCalling -> {
                    startRingback()
                    startTimeoutJob(30_000L, "Outgoing call timeout") {
                        sendSignalingPacket(newState.targetAddress, "CALL_END", DEFAULT_AUDIO_PORT)
                        transitionTo(CallState.Missed("لم يتم الرد على المكالمة"), "Outgoing calling timeout")
                    }
                }

                is CallState.IncomingRinging -> {
                    startIncomingRingtoneAndVibration()
                    LanService.showCallNotification(context, newState.callerName, newState.callerAddress)
                    startTimeoutJob(30_000L, "Incoming call answer timeout") {
                        sendSignalingPacket(newState.callerAddress, "CALL_REJECT", DEFAULT_AUDIO_PORT)
                        transitionTo(CallState.Missed("مكالمة لم يرد عليها"), "Incoming ringing timeout")
                    }
                }

                is CallState.Connecting -> {
                    stopRingback()
                    stopIncomingRingtoneAndVibration()
                    LanService.cancelCallNotification(context)
                    startTimeoutJob(10_000L, "Connecting audio session timeout") {
                        transitionTo(CallState.Failed("تعذر إنشاء الجلسة الصوتية"), "Connection setup timeout")
                    }
                }

                is CallState.ActiveCall -> {
                    stopRingback()
                    stopIncomingRingtoneAndVibration()
                    LanService.cancelCallNotification(context)
                    cancelTimeoutJob()
                    startActiveAudioSession(newState)
                }

                is CallState.Busy, is CallState.Rejected, is CallState.Missed, is CallState.Ended, is CallState.Failed -> {
                    handleTerminalState(oldState, newState, reason)
                }

                is CallState.Idle -> {
                    stopAllCallResources()
                }
            }
        }
    }

    private suspend fun handleTerminalState(oldState: CallState, newState: CallState, reason: String) {
        stopAllCallResources()

        // Get peer address from previous state to send AVAILABLE notice if relevant
        val peerAddress = when (oldState) {
            is CallState.OutgoingCalling -> oldState.targetAddress
            is CallState.IncomingRinging -> oldState.callerAddress
            is CallState.Connecting -> oldState.peerAddress
            is CallState.ActiveCall -> oldState.peerAddress
            else -> null
        }

        if (peerAddress != null) {
            scope.launch {
                sendSignalingPacket(peerAddress, "AVAILABLE", DEFAULT_AUDIO_PORT)
            }
        }

        resetToIdleJob?.cancel()
        resetToIdleJob = scope.launch {
            delay(2000)
            stateMutex.withLock {
                if (_callState.value == newState) {
                    Log.d(TAG, "Auto-resetting state from [${newState::class.simpleName}] to [Idle]")
                    _callState.value = CallState.Idle
                    stopAllCallResources()
                }
            }
        }
    }

    // --- Public Call Operations ---

    fun initiateCall(targetName: String, targetAddress: String) {
        scope.launch {
            val currentState = _callState.value
            if (currentState.isInCallOrRinging) {
                Log.w(TAG, "Cannot initiate call, device currently in call state: $currentState")
                return@launch
            }

            transitionTo(CallState.OutgoingCalling(targetName, targetAddress), "User initiated outgoing call")

            // Send initial CALL_OFFER
            val sent = sendSignalingPacket(targetAddress, "CALL_OFFER", DEFAULT_AUDIO_PORT)
            if (!sent) {
                transitionTo(
                    CallState.Failed("تعذر إرسال طلب المكالمة. تأكد من الاتصال بالشبكة المحلية."),
                    "Signaling CALL_OFFER failed to send"
                )
                return@launch
            }

            // Periodically re-send CALL_OFFER while state remains OutgoingCalling to combat packet loss
            scope.launch {
                while (isActive && _callState.value is CallState.OutgoingCalling) {
                    delay(2000)
                    if (_callState.value is CallState.OutgoingCalling) {
                        sendSignalingPacket(targetAddress, "CALL_OFFER", DEFAULT_AUDIO_PORT)
                    }
                }
            }
        }
    }

    fun onIncomingCallOffer(callerName: String, callerAddress: String, callerAudioPort: Int) {
        scope.launch {
            val currentState = _callState.value
            if (!currentState.isInCallOrRinging) {
                transitionTo(
                    CallState.IncomingRinging(callerName, callerAddress, callerAudioPort),
                    "Received incoming CALL_OFFER from $callerName ($callerAddress)"
                )
            } else if (currentState is CallState.IncomingRinging && currentState.callerAddress == callerAddress) {
                Log.d(TAG, "Duplicate CALL_OFFER from $callerAddress received, ignoring duplicate packet")
            } else if (currentState is CallState.OutgoingCalling && currentState.targetAddress == callerAddress) {
                Log.d(TAG, "Simultaneous call with $callerAddress, auto-transitioning to ActiveCall")
                transitionTo(
                    CallState.ActiveCall(
                        peerName = callerName,
                        peerAddress = callerAddress,
                        durationSeconds = 0,
                        isMuted = isMuted,
                        isSpeakerOn = isSpeakerOn
                    ),
                    "Simultaneous call collision resolved"
                )
            } else {
                Log.w(TAG, "Device busy ($currentState), rejecting incoming call from $callerAddress with CALL_BUSY")
                scope.launch {
                    sendSignalingPacket(callerAddress, "CALL_BUSY", DEFAULT_AUDIO_PORT)
                }
            }
        }
    }

    fun acceptCall() {
        scope.launch {
            val currentState = _callState.value
            if (currentState !is CallState.IncomingRinging) return@launch

            val callerAddress = currentState.callerAddress
            val callerName = currentState.callerName

            scope.launch {
                repeat(3) {
                    sendSignalingPacket(callerAddress, "CALL_ACCEPT", DEFAULT_AUDIO_PORT)
                    delay(120)
                }
            }

            transitionTo(
                CallState.ActiveCall(
                    peerName = callerName,
                    peerAddress = callerAddress,
                    durationSeconds = 0,
                    isMuted = isMuted,
                    isSpeakerOn = isSpeakerOn
                ),
                "Call accepted by local user"
            )
        }
    }

    fun rejectCall() {
        scope.launch {
            val currentState = _callState.value
            if (currentState is CallState.IncomingRinging) {
                val callerAddress = currentState.callerAddress
                scope.launch {
                    sendSignalingPacket(callerAddress, "CALL_REJECT", DEFAULT_AUDIO_PORT)
                }
            }
            transitionTo(CallState.Rejected("تم رفض المكالمة"), "Call rejected by local user")
        }
    }

    fun endCall() {
        scope.launch {
            val currentState = _callState.value
            val peerAddress = when (currentState) {
                is CallState.OutgoingCalling -> currentState.targetAddress
                is CallState.IncomingRinging -> currentState.callerAddress
                is CallState.Connecting -> currentState.peerAddress
                is CallState.ActiveCall -> currentState.peerAddress
                else -> null
            }

            if (peerAddress != null) {
                scope.launch {
                    sendSignalingPacket(peerAddress, "CALL_END", DEFAULT_AUDIO_PORT)
                }
            }

            transitionTo(CallState.Ended("تم إنهاء المكالمة"), "Call ended by local user")
        }
    }

    // --- Signaling Event Ingestion ---

    fun onCallAccepted(peerAddress: String, remoteAudioPort: Int) {
        scope.launch {
            val currentState = _callState.value
            if (currentState is CallState.OutgoingCalling || currentState is CallState.Connecting) {
                val name = when (currentState) {
                    is CallState.OutgoingCalling -> currentState.targetName
                    is CallState.Connecting -> currentState.peerName
                    else -> "جهاز $peerAddress"
                }
                transitionTo(
                    CallState.ActiveCall(
                        peerName = name,
                        peerAddress = peerAddress,
                        durationSeconds = 0,
                        isMuted = isMuted,
                        isSpeakerOn = isSpeakerOn
                    ),
                    "Received CALL_ACCEPT from peer"
                )
            }
        }
    }

    fun onCallRejected() {
        scope.launch {
            transitionTo(CallState.Rejected("تم رفض المكالمة من الطرف الآخر"), "Received CALL_REJECT from peer")
        }
    }

    fun onCallBusy() {
        scope.launch {
            transitionTo(CallState.Busy("الطرف الآخر مشغول بمكالمة أخرى"), "Received CALL_BUSY from peer")
        }
    }

    fun onCallEndedByPeer() {
        scope.launch {
            transitionTo(CallState.Ended("تم إنهاء المكالمة من الطرف الآخر"), "Received CALL_END from peer")
        }
    }

    fun onHeartbeatReceived(peerAddress: String) {
        val currentState = _callState.value
        if (currentState is CallState.ActiveCall && currentState.peerAddress == peerAddress) {
            lastPeerActivityTimestamp = System.currentTimeMillis()
        }
    }

    fun onNetworkLost() {
        scope.launch {
            val currentState = _callState.value
            if (currentState.isInCallOrRinging) {
                transitionTo(CallState.Failed("انقطع الاتصال بالشبكة المحلية"), "LAN network lost")
            } else {
                stopAllCallResources()
                _callState.value = CallState.Idle
            }
        }
    }

    fun toggleMute() {
        scope.launch {
            stateMutex.withLock {
                val currentState = _callState.value
                if (currentState is CallState.ActiveCall) {
                    isMuted = !isMuted
                    _callState.value = currentState.copy(isMuted = isMuted)
                }
            }
        }
    }

    fun toggleSpeaker() {
        scope.launch {
            stateMutex.withLock {
                val currentState = _callState.value
                if (currentState is CallState.ActiveCall) {
                    isSpeakerOn = !isSpeakerOn
                    setSpeakerphoneState(isSpeakerOn)
                    _callState.value = currentState.copy(isSpeakerOn = isSpeakerOn)
                }
            }
        }
    }

    private fun setSpeakerphoneState(on: Boolean) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (on) {
                    val devices = audioManager.availableCommunicationDevices
                    val speakerDevice = devices.find { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
                    if (speakerDevice != null) {
                        audioManager.setCommunicationDevice(speakerDevice)
                    }
                } else {
                    audioManager.clearCommunicationDevice()
                }
            } else {
                @Suppress("DEPRECATION")
                audioManager.isSpeakerphoneOn = on
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error toggling speakerphone: ${e.message}")
        }
    }

    // --- Audio Session Engine ---

    private fun startActiveAudioSession(activeState: CallState.ActiveCall) {
        stopRingback()
        stopIncomingRingtoneAndVibration()
        isMuted = activeState.isMuted
        isSpeakerOn = activeState.isSpeakerOn

        acquireWakeLock()
        setupAudioHardware()

        lastPeerActivityTimestamp = System.currentTimeMillis()

        // 1. Duration Counter Timer
        timerJob?.cancel()
        timerJob = scope.launch {
            var duration = 0L
            while (isActive && _callState.value is CallState.ActiveCall) {
                delay(1000)
                duration++
                stateMutex.withLock {
                    val current = _callState.value as? CallState.ActiveCall
                    if (current != null) {
                        _callState.value = current.copy(durationSeconds = duration)
                    }
                }
            }
        }

        // 2. Heartbeat Loop & Connection Monitor
        heartbeatJob?.cancel()
        heartbeatJob = scope.launch {
            while (isActive && _callState.value is CallState.ActiveCall) {
                delay(HEARTBEAT_INTERVAL_MS)
                sendSignalingPacket(activeState.peerAddress, "CALL_HEARTBEAT", DEFAULT_AUDIO_PORT)

                val elapsedSincePeerActivity = System.currentTimeMillis() - lastPeerActivityTimestamp
                if (elapsedSincePeerActivity > HEARTBEAT_TIMEOUT_MS) {
                    Log.w(TAG, "No audio or heartbeat from peer for ${elapsedSincePeerActivity}ms, failing call")
                    transitionTo(CallState.Failed("فقدان الاتصال مع الطرف الآخر"), "Peer heartbeat timeout")
                    break
                }
            }
        }

        // 3. Audio Streaming & Metrics
        packetsSent = 0L
        packetsReceived = 0L
        packetsDropped = 0L
        lastCalculatedLatencyMs = 0L

        startAudioRecorder(activeState.peerAddress, DEFAULT_AUDIO_PORT)
        startAudioPlayer()
    }

    private fun setupAudioHardware() {
        try {
            originalAudioMode = audioManager.mode
            originalSpeakerState = audioManager.isSpeakerphoneOn

            audioManager.mode = AudioManager.MODE_IN_COMMUNICATION
            setSpeakerphoneState(isSpeakerOn)
        } catch (e: Exception) {
            Log.e(TAG, "Failed setting up AudioManager: ${e.message}")
        }
    }

    private class VoiceJitterBuffer(
        private val targetDepthFrames: Int = 3,
        private val maxDepthFrames: Int = 12
    ) {
        private val lock = Any()
        private val frameMap = ConcurrentSkipListMap<Int, ByteArray>()
        private var lastPlayedSequence = -1
        private var isPrebuffered = false

        fun push(seq: Int, payload: ByteArray) {
            synchronized(lock) {
                if (lastPlayedSequence != -1 && seq <= lastPlayedSequence) {
                    return // Drop stale frame
                }
                if (frameMap.size >= maxDepthFrames) {
                    val oldest = frameMap.firstKey()
                    frameMap.remove(oldest)
                }
                frameMap[seq] = payload
            }
        }

        fun popFrame(): ByteArray? {
            synchronized(lock) {
                if (!isPrebuffered) {
                    if (frameMap.size >= targetDepthFrames) {
                        isPrebuffered = true
                    } else {
                        return null
                    }
                }

                if (frameMap.isEmpty()) {
                    isPrebuffered = false
                    return null
                }

                val nextSeq = frameMap.firstKey()
                val frame = frameMap.remove(nextSeq)
                lastPlayedSequence = nextSeq
                return frame
            }
        }

        fun reset() {
            synchronized(lock) {
                frameMap.clear()
                lastPlayedSequence = -1
                isPrebuffered = false
            }
        }

        fun size(): Int = synchronized(lock) { frameMap.size }
    }

    private fun startAudioRecorder(peerAddress: String, remoteAudioPort: Int) {
        recordJob?.cancel()
        recordJob = scope.launch(Dispatchers.IO) {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            val minBufferSize = AudioRecord.getMinBufferSize(
                SAMPLE_RATE, CHANNEL_CONFIG_IN, AUDIO_FORMAT
            )
            val bufferSize = Math.max(minBufferSize, 3200)

            var recorder: AudioRecord? = null
            try {
                try {
                    recorder = AudioRecord(
                        MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                        SAMPLE_RATE,
                        CHANNEL_CONFIG_IN,
                        AUDIO_FORMAT,
                        bufferSize
                    )
                } catch (e: Exception) {
                    Log.w(TAG, "VOICE_COMMUNICATION source failed, falling back to MIC: ${e.message}")
                    recorder = AudioRecord(
                        MediaRecorder.AudioSource.MIC,
                        SAMPLE_RATE,
                        CHANNEL_CONFIG_IN,
                        AUDIO_FORMAT,
                        bufferSize
                    )
                }

                if (recorder.state != AudioRecord.STATE_INITIALIZED) {
                    Log.e(TAG, "AudioRecord failed to initialize")
                    _callEvents.emit("خطأ في تشغيل الميكروفون")
                    return@launch
                }

                // Attach Hardware Audio Effects for clear voice
                if (AcousticEchoCanceler.isAvailable()) {
                    try {
                        echoCanceler = AcousticEchoCanceler.create(recorder.audioSessionId)
                        echoCanceler?.enabled = true
                        Log.d(TAG, "AcousticEchoCanceler enabled on session ${recorder.audioSessionId}")
                    } catch (e: Exception) {
                        Log.w(TAG, "AcousticEchoCanceler enable failed: ${e.message}")
                    }
                }
                if (AutomaticGainControl.isAvailable()) {
                    try {
                        gainControl = AutomaticGainControl.create(recorder.audioSessionId)
                        gainControl?.enabled = true
                        Log.d(TAG, "AutomaticGainControl enabled on session ${recorder.audioSessionId}")
                    } catch (e: Exception) {
                        Log.w(TAG, "AutomaticGainControl enable failed: ${e.message}")
                    }
                }
                if (NoiseSuppressor.isAvailable()) {
                    try {
                        noiseSuppressor = NoiseSuppressor.create(recorder.audioSessionId)
                        noiseSuppressor?.enabled = true
                        Log.d(TAG, "NoiseSuppressor enabled on session ${recorder.audioSessionId}")
                    } catch (e: Exception) {
                        Log.w(TAG, "NoiseSuppressor enable failed: ${e.message}")
                    }
                }

                audioRecord = recorder
                val socket = DatagramSocket().apply {
                    sendBufferSize = 128 * 1024
                    try { trafficClass = 0x28 } catch (_: Exception) {}
                }
                val peerInetAddress = InetAddress.getByName(peerAddress)
                val buffer = ByteArray(FRAME_SIZE_BYTES)
                var sequenceNum = 0
                val packetBuffer = ByteBuffer.allocate(PACKET_SIZE)

                recorder.startRecording()
                Log.d(TAG, "AudioRecord streaming started to $peerAddress:$remoteAudioPort")

                while (isActive && recorder.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                    val readBytes = recorder.read(buffer, 0, buffer.size)
                    if (readBytes > 0) {
                        val payloadToSend = if (isMuted) ByteArray(readBytes) else buffer

                        packetBuffer.clear()
                        packetBuffer.putInt(MAGIC_HEADER)
                        packetBuffer.putInt(sequenceNum++)
                        packetBuffer.putLong(System.currentTimeMillis())
                        packetBuffer.put(payloadToSend, 0, readBytes)

                        val packet = DatagramPacket(
                            packetBuffer.array(),
                            PACKET_SIZE,
                            peerInetAddress,
                            remoteAudioPort
                        )
                        socket.send(packet)
                        packetsSent++
                    }
                }
                try { socket.close() } catch (_: Exception) {}
            } catch (e: Exception) {
                Log.e(TAG, "AudioRecord stream exception: ${e.message}")
            } finally {
                try {
                    recorder?.stop()
                    recorder?.release()
                } catch (_: Exception) {}
            }
        }
    }

    private fun startAudioPlayer() {
        playJob?.cancel()
        playJob = scope.launch(Dispatchers.IO) {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
            val minBufferSize = AudioTrack.getMinBufferSize(
                SAMPLE_RATE, CHANNEL_CONFIG_OUT, AUDIO_FORMAT
            )
            val bufferSize = Math.max(minBufferSize * 2, 6400)

            try {
                audioTrack = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    AudioTrack.Builder()
                        .setAudioAttributes(
                            AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                                .build()
                        )
                        .setAudioFormat(
                            AudioFormat.Builder()
                                .setEncoding(AUDIO_FORMAT)
                                .setSampleRate(SAMPLE_RATE)
                                .setChannelMask(CHANNEL_CONFIG_OUT)
                                .build()
                        )
                        .setBufferSizeInBytes(bufferSize)
                        .setTransferMode(AudioTrack.MODE_STREAM)
                        .build()
                } else {
                    @Suppress("DEPRECATION")
                    AudioTrack(
                        AudioManager.STREAM_VOICE_CALL,
                        SAMPLE_RATE,
                        CHANNEL_CONFIG_OUT,
                        AUDIO_FORMAT,
                        bufferSize,
                        AudioTrack.MODE_STREAM
                    )
                }

                if (audioTrack?.state != AudioTrack.STATE_INITIALIZED) {
                    Log.e(TAG, "AudioTrack failed to initialize")
                    return@launch
                }

                audioTrack?.play()

                var socket: DatagramSocket? = null
                for (attempt in 1..5) {
                    try {
                        try { audioUdpSocket?.close() } catch (_: Exception) {}
                        socket = DatagramSocket(null).apply {
                            reuseAddress = true
                            receiveBufferSize = 128 * 1024
                            try { trafficClass = 0x28 } catch (_: Exception) {}
                            bind(java.net.InetSocketAddress(DEFAULT_AUDIO_PORT))
                            soTimeout = 500
                        }
                        audioUdpSocket = socket
                        break
                    } catch (e: Exception) {
                        Log.w(TAG, "Audio socket bind attempt $attempt failed: ${e.message}")
                        delay(100)
                    }
                }

                if (socket == null || socket.isClosed) {
                    Log.e(TAG, "Failed to bind AudioTrack UDP socket on port $DEFAULT_AUDIO_PORT")
                    return@launch
                }

                val jitterBuffer = VoiceJitterBuffer(targetDepthFrames = 3, maxDepthFrames = 12)

                val writerJob = launch(Dispatchers.IO) {
                    Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
                    val silencePadding = ByteArray(FRAME_SIZE_BYTES)

                    while (isActive && audioTrack?.playState == AudioTrack.PLAYSTATE_PLAYING) {
                        val frame = jitterBuffer.popFrame()
                        if (frame != null) {
                            audioTrack?.write(frame, 0, frame.size)
                        } else {
                            // Smooth buffer underflow padding
                            audioTrack?.write(silencePadding, 0, silencePadding.size)
                            delay(5)
                        }
                    }
                }

                metricsJob?.cancel()
                metricsJob = launch(Dispatchers.IO) {
                    while (isActive && _callState.value is CallState.ActiveCall) {
                        delay(3000)
                        val totalExpected = packetsReceived + packetsDropped
                        val lossRate = if (totalExpected > 0) (packetsDropped.toDouble() / totalExpected.toDouble() * 100.0) else 0.0
                        Log.d(
                            TAG,
                            "[VoIP Metrics] Sent: $packetsSent | Recv: $packetsReceived | Loss: %.1f%% | Latency: ${lastCalculatedLatencyMs}ms | JitterBuf: ${jitterBuffer.size()} frames"
                        )
                    }
                }

                val receiveBuffer = ByteArray(PACKET_SIZE + 256)
                var lastReceivedSeq = -1
                Log.d(TAG, "AudioTrack player listening on UDP port $DEFAULT_AUDIO_PORT with JitterBuffer")

                while (isActive && audioTrack?.playState == AudioTrack.PLAYSTATE_PLAYING) {
                    try {
                        val packet = DatagramPacket(receiveBuffer, receiveBuffer.size)
                        socket.receive(packet)
                        val length = packet.length

                        if (length >= HEADER_SIZE) {
                            lastPeerActivityTimestamp = System.currentTimeMillis()
                            val byteBuf = ByteBuffer.wrap(packet.data, packet.offset, length)
                            val magic = byteBuf.getInt()

                            if (magic == MAGIC_HEADER) {
                                val seq = byteBuf.getInt()
                                val timestamp = byteBuf.getLong()

                                val now = System.currentTimeMillis()
                                if (now >= timestamp) {
                                    lastCalculatedLatencyMs = now - timestamp
                                }

                                if (lastReceivedSeq != -1 && seq > lastReceivedSeq + 1) {
                                    packetsDropped += (seq - lastReceivedSeq - 1)
                                }
                                if (lastReceivedSeq == -1 || seq > lastReceivedSeq) {
                                    lastReceivedSeq = seq
                                }

                                val payloadLen = length - HEADER_SIZE
                                if (payloadLen > 0) {
                                    val payload = ByteArray(payloadLen)
                                    byteBuf.get(payload)
                                    jitterBuffer.push(seq, payload)
                                    packetsReceived++
                                }
                            } else if (length >= FRAME_SIZE_BYTES) {
                                val legacyPayload = packet.data.copyOfRange(packet.offset, packet.offset + length)
                                jitterBuffer.push(++lastReceivedSeq, legacyPayload)
                                packetsReceived++
                            }
                        }
                    } catch (_: java.net.SocketTimeoutException) {
                        // Periodic timeout to evaluate coroutine isActive state
                    }
                }

                writerJob.cancel()
                metricsJob?.cancel()
            } catch (e: Exception) {
                Log.e(TAG, "AudioTrack player exception: ${e.message}")
            } finally {
                try { audioUdpSocket?.close() } catch (_: Exception) {}
            }
        }
    }

    // --- Cleanup & Teardown Utilities ---

    private fun stopAllCallResources() {
        cancelTimeoutJob()
        cancelHeartbeatJob()
        
        stopRingback()
        stopIncomingRingtoneAndVibration()
        LanService.cancelCallNotification(context)

        stopAudioEngine()
        releaseWakeLock()
    }

    private fun stopAudioEngine() {
        timerJob?.cancel()
        timerJob = null
        recordJob?.cancel()
        recordJob = null
        playJob?.cancel()
        playJob = null
        metricsJob?.cancel()
        metricsJob = null

        try {
            echoCanceler?.enabled = false
            echoCanceler?.release()
        } catch (_: Exception) {}
        echoCanceler = null

        try {
            gainControl?.enabled = false
            gainControl?.release()
        } catch (_: Exception) {}
        gainControl = null

        try {
            noiseSuppressor?.enabled = false
            noiseSuppressor?.release()
        } catch (_: Exception) {}
        noiseSuppressor = null

        try {
            audioRecord?.stop()
            audioRecord?.release()
        } catch (_: Exception) {}
        audioRecord = null

        try {
            audioTrack?.stop()
            audioTrack?.release()
        } catch (_: Exception) {}
        audioTrack = null

        try {
            audioUdpSocket?.close()
        } catch (_: Exception) {}
        audioUdpSocket = null

        try {
            audioManager.mode = originalAudioMode
            audioManager.isSpeakerphoneOn = originalSpeakerState
        } catch (_: Exception) {}
    }

    private fun startRingback() {
        try {
            stopRingback()
            ringbackTone = ToneGenerator(AudioManager.STREAM_VOICE_CALL, 80)
            ringbackTone?.startTone(ToneGenerator.TONE_SUP_RINGTONE, 28000)
        } catch (e: Exception) {
            Log.e(TAG, "Error playing ringback tone: ${e.message}")
        }
    }

    private fun stopRingback() {
        try {
            ringbackTone?.stopTone()
            ringbackTone?.release()
        } catch (_: Exception) {}
        ringbackTone = null
    }

    private fun startIncomingRingtoneAndVibration() {
        try {
            stopIncomingRingtoneAndVibration()

            val ringtoneUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            incomingRingtone = RingtoneManager.getRingtone(context, ringtoneUri)
            incomingRingtone?.play()

            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }

            vibrator?.let {
                val pattern = longArrayOf(0, 1000, 500, 1000)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    it.vibrate(VibrationEffect.createWaveform(pattern, 0))
                } else {
                    @Suppress("DEPRECATION")
                    it.vibrate(pattern, 0)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error playing incoming ringtone or vibration: ${e.message}")
        }
    }

    private fun stopIncomingRingtoneAndVibration() {
        try {
            incomingRingtone?.stop()
            incomingRingtone = null

            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
            vibrator?.cancel()
        } catch (_: Exception) {}
    }

    private fun acquireWakeLock() {
        try {
            if (wakeLock == null) {
                val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "Wasel:VoiceCallWakeLock")
            }
            if (wakeLock?.isHeld == false) {
                wakeLock?.acquire(10 * 60 * 1000L /*10 mins max fallback*/)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed acquiring WakeLock: ${e.message}")
        }
    }

    private fun releaseWakeLock() {
        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        } catch (_: Exception) {}
        wakeLock = null
    }

    private fun startTimeoutJob(durationMs: Long, timeoutReason: String, onTimeout: suspend () -> Unit) {
        cancelTimeoutJob()
        timeoutJob = scope.launch {
            delay(durationMs)
            Log.w(TAG, "Timeout triggered: $timeoutReason")
            onTimeout()
        }
    }

    private fun cancelTimeoutJob() {
        timeoutJob?.cancel()
        timeoutJob = null
    }

    private fun cancelHeartbeatJob() {
        heartbeatJob?.cancel()
        heartbeatJob = null
    }

    fun cleanUp() {
        Log.d(TAG, "Cleaning up VoiceCallManager completely")
        stopAllCallResources()
        _callState.value = CallState.Idle
    }
}
