package com.example

import android.app.Application
import com.example.data.local.AppDatabase
import com.example.data.local.NotificationSettingsManager
import com.example.data.network.LanController
import com.example.data.network.LanService
import com.example.data.repository.ChatRepository

class WaselApplication : Application() {

    lateinit var database: AppDatabase
        private set

    lateinit var lanController: LanController
        private set

    lateinit var chatRepository: ChatRepository
        private set

    lateinit var notificationSettings: NotificationSettingsManager
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        // Initialize local database, settings, and network controller
        database = AppDatabase.getInstance(this)
        lanController = LanController(this)
        chatRepository = ChatRepository(database.messageDao(), lanController)
        notificationSettings = NotificationSettingsManager(this)

        if (notificationSettings.isPersistentBackgroundEnabled()) {
            LanService.startService(this)
        }
    }

    companion object {
        lateinit var instance: WaselApplication
            private set
    }
}
