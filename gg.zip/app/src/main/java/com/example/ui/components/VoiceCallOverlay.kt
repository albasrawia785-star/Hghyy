package com.example.ui.components

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhoneInTalk
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.example.data.network.CallState
import com.example.ui.theme.WaselGreenPrimary
import java.util.Locale

@Composable
fun VoiceCallOverlay(
    callState: CallState,
    onAccept: () -> Unit,
    onReject: () -> Unit,
    onEnd: () -> Unit,
    onToggleMute: () -> Unit,
    onToggleSpeaker: () -> Unit
) {
    val context = LocalContext.current

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted && callState is CallState.IncomingRinging) {
            onAccept()
        }
    }

    val isCallActiveOrRinging = callState !is CallState.Idle

    if (!isCallActiveOrRinging) return

    Dialog(
        onDismissRequest = {},
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = false,
            dismissOnClickOutside = false
        )
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.98f)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxSize()
                ) {

                    // Top Header Title
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(top = 32.dp)
                    ) {
                        Text(
                            text = "مكالمة صوتية مباشرة (شبكة محليّة)",
                            style = MaterialTheme.typography.titleMedium,
                            color = WaselGreenPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = when (callState) {
                                is CallState.OutgoingCalling -> "جاري الاتصال..."
                                is CallState.IncomingRinging -> "مكالمة واردة"
                                is CallState.Connecting -> "جاري إنشاء الاتصال..."
                                is CallState.ActiveCall -> "مكالمة جارية"
                                is CallState.Busy -> "مشغول"
                                is CallState.Rejected -> "تم رفض المكالمة"
                                is CallState.Missed -> "لم يتم الرد"
                                is CallState.Ended -> "انتهاء المكالمة"
                                is CallState.Failed -> "فشل الاتصال"
                                else -> ""
                            },
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Central Device Avatar & Peer Info
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(110.dp)
                                .clip(CircleShape)
                                .background(WaselGreenPrimary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Person,
                                contentDescription = null,
                                modifier = Modifier.size(64.dp),
                                tint = WaselGreenPrimary
                            )
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        val peerName = when (callState) {
                            is CallState.OutgoingCalling -> callState.targetName
                            is CallState.IncomingRinging -> callState.callerName
                            is CallState.Connecting -> callState.peerName
                            is CallState.ActiveCall -> callState.peerName
                            is CallState.Busy -> callState.reason
                            is CallState.Rejected -> callState.reason
                            is CallState.Missed -> callState.reason
                            is CallState.Ended -> callState.reason
                            is CallState.Failed -> callState.reason
                            else -> ""
                        }

                        Text(
                            text = peerName,
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        if (callState is CallState.ActiveCall) {
                            Text(
                                text = formatCallDuration(callState.durationSeconds),
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.SemiBold,
                                color = WaselGreenPrimary,
                                fontSize = 28.sp
                            )
                        } else if (callState is CallState.OutgoingCalling) {
                            Text(
                                text = callState.targetAddress,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.outline
                            )
                        } else if (callState is CallState.IncomingRinging) {
                            Text(
                                text = callState.callerAddress,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.outline
                            )
                        }
                    }

                    // Bottom Actions Bar
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(bottom = 36.dp)
                    ) {
                        when (callState) {
                            is CallState.IncomingRinging -> {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceEvenly,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Reject Call Button
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        IconButton(
                                            onClick = onReject,
                                            modifier = Modifier
                                                .size(68.dp)
                                                .testTag("reject_call_button"),
                                            colors = IconButtonDefaults.iconButtonColors(
                                                containerColor = MaterialTheme.colorScheme.error
                                            )
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.CallEnd,
                                                contentDescription = "رفض المكالمة",
                                                tint = Color.White,
                                                modifier = Modifier.size(32.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(text = "رفض", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                                    }

                                    // Accept Call Button
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        IconButton(
                                            onClick = {
                                                val hasMicPermission = ContextCompat.checkSelfPermission(
                                                    context,
                                                    Manifest.permission.RECORD_AUDIO
                                                ) == PackageManager.PERMISSION_GRANTED

                                                if (hasMicPermission) {
                                                    onAccept()
                                                } else {
                                                    permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                                }
                                            },
                                            modifier = Modifier
                                                .size(68.dp)
                                                .testTag("accept_call_button"),
                                            colors = IconButtonDefaults.iconButtonColors(
                                                containerColor = WaselGreenPrimary
                                            )
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Call,
                                                contentDescription = "الرد على المكالمة",
                                                tint = Color.White,
                                                modifier = Modifier.size(32.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(text = "رد", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            is CallState.ActiveCall -> {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceEvenly,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        // Toggle Mute Button
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            IconButton(
                                                onClick = onToggleMute,
                                                modifier = Modifier.size(56.dp),
                                                colors = IconButtonDefaults.iconButtonColors(
                                                    containerColor = if (callState.isMuted) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surfaceVariant
                                                )
                                            ) {
                                                Icon(
                                                    imageVector = if (callState.isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                                                    contentDescription = "كتم الصوت",
                                                    tint = if (callState.isMuted) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(
                                                text = if (callState.isMuted) "كتم مفعل" else "كتم",
                                                style = MaterialTheme.typography.bodySmall
                                            )
                                        }

                                        // End Call Button
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            IconButton(
                                                onClick = onEnd,
                                                modifier = Modifier
                                                    .size(68.dp)
                                                    .testTag("end_active_call_button"),
                                                colors = IconButtonDefaults.iconButtonColors(
                                                    containerColor = MaterialTheme.colorScheme.error
                                                )
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.CallEnd,
                                                    contentDescription = "إنهاء المكالمة",
                                                    tint = Color.White,
                                                    modifier = Modifier.size(32.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(
                                                text = "إنهاء",
                                                style = MaterialTheme.typography.bodyMedium,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }

                                        // Toggle Speaker Button
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            IconButton(
                                                onClick = onToggleSpeaker,
                                                modifier = Modifier.size(56.dp),
                                                colors = IconButtonDefaults.iconButtonColors(
                                                    containerColor = if (callState.isSpeakerOn) WaselGreenPrimary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surfaceVariant
                                                )
                                            ) {
                                                Icon(
                                                    imageVector = if (callState.isSpeakerOn) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                                                    contentDescription = "مكبر الصوت",
                                                    tint = if (callState.isSpeakerOn) WaselGreenPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(
                                                text = if (callState.isSpeakerOn) "سماعة" else "عادي",
                                                style = MaterialTheme.typography.bodySmall
                                            )
                                        }
                                    }
                                }
                            }

                            is CallState.OutgoingCalling, is CallState.Connecting -> {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    IconButton(
                                        onClick = onEnd,
                                        modifier = Modifier
                                            .size(68.dp)
                                            .testTag("cancel_outgoing_call_button"),
                                        colors = IconButtonDefaults.iconButtonColors(
                                            containerColor = MaterialTheme.colorScheme.error
                                        )
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.CallEnd,
                                            contentDescription = "إلغاء الاتصال",
                                            tint = Color.White,
                                            modifier = Modifier.size(32.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(text = "إلغاء", style = MaterialTheme.typography.bodyMedium)
                                }
                            }

                            is CallState.Busy, is CallState.Rejected, is CallState.Missed, is CallState.Ended, is CallState.Failed -> {
                                Text(
                                    text = "جاري العودة للدردشة...",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.outline
                                )
                            }

                            else -> {}
                        }
                    }
                }
            }
        }
    }
}

private fun formatCallDuration(seconds: Long): String {
    val mins = seconds / 60
    val secs = seconds % 60
    return String.format(Locale.getDefault(), "%02d:%02d", mins, secs)
}
