package com.example.ui.components

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.NotificationsOff
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.example.BuildConfig
import com.example.domain.model.ConnectionRequest
import com.example.domain.model.DeviceDomain
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WaselGreenContainer
import com.example.ui.theme.WaselGreenPrimary

@Composable
fun AboutDialog(
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val versionName = try {
        BuildConfig.VERSION_NAME
    } catch (_: Exception) {
        "1.0"
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = null,
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header Icon
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF25D366).copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Forum,
                        contentDescription = null,
                        tint = Color(0xFF128C7E),
                        modifier = Modifier.size(32.dp)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Section 1: معلومات التطبيق
                Text(
                    text = "معلومات التطبيق",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "اسم التطبيق: واصل",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "الإصدار: $versionName",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "جميع الحقوق محفوظة © 2026",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                )

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(modifier = Modifier.fillMaxWidth(0.9f), color = MaterialTheme.colorScheme.outlineVariant)
                Spacer(modifier = Modifier.height(16.dp))

                // Section 2: المطور
                Text(
                    text = "المطور",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "تطوير وبرمجة: Ali",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(modifier = Modifier.fillMaxWidth(0.9f), color = MaterialTheme.colorScheme.outlineVariant)
                Spacer(modifier = Modifier.height(16.dp))

                // Section 3: الدعم والتواصل
                Text(
                    text = "الدعم والتواصل",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )

                Spacer(modifier = Modifier.height(12.dp))

                // WhatsApp Contact Button (No phone number displayed)
                Button(
                    onClick = {
                        try {
                            val whatsappUri = Uri.parse("https://api.whatsapp.com/send?phone=9647810936407")
                            val intent = Intent(Intent.ACTION_VIEW, whatsappUri).apply {
                                setPackage("com.whatsapp")
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            try {
                                val fallbackUri = Uri.parse("https://wa.me/9647810936407")
                                val fallbackIntent = Intent(Intent.ACTION_VIEW, fallbackUri).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                context.startActivity(fallbackIntent)
                            } catch (e2: Exception) {
                                Toast.makeText(
                                    context,
                                    "تطبيق WhatsApp غير مثبت على هذا الجهاز.",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF25D366),
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(20.dp),
                    contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .testTag("whatsapp_contact_button")
                ) {
                    Box(
                        modifier = Modifier
                            .size(22.dp)
                            .clip(CircleShape)
                            .background(Color.White),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Forum,
                            contentDescription = null,
                            tint = Color(0xFF25D366),
                            modifier = Modifier.size(14.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "التواصل عبر واتساب",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("about_dialog_close")
            ) {
                Text(
                    text = "إغلاق",
                    fontWeight = FontWeight.Bold
                )
            }
        }
    )
}

@Composable
fun DeleteConfirmDialog(
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Default.DeleteSweep,
                contentDescription = "حذف المحادثات",
                tint = MaterialTheme.colorScheme.error
            )
        },
        title = {
            Text(
                text = "حذف جميع المحادثات",
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Text(
                text = "هل أنت تأكد من أنك تريد مسح كل الرسائل والمحادثات المحفوظة من الجهاز؟ لا يمكن التراجع عن هذا الإجراء.",
                style = MaterialTheme.typography.bodyMedium
            )
        },
        confirmButton = {
            TextButton(
                onClick = onConfirm,
                modifier = Modifier.testTag("confirm_delete_button")
            ) {
                Text(
                    text = "حذف الكل",
                    color = MaterialTheme.colorScheme.error
                )
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_delete_button")
            ) {
                Text("إلغاء")
            }
        }
    )
}

private enum class SettingsSubScreen {
    MAIN,
    BACKGROUND_WORK,
    ABOUT_APP,
    DEVELOPER_RIGHTS
}

@Composable
fun SettingsDialog(
    notificationsEnabled: Boolean,
    persistentBackgroundEnabled: Boolean = true,
    soundTitle: String,
    soundUri: String,
    onToggleNotifications: (Boolean) -> Unit,
    onTogglePersistentBackground: (Boolean) -> Unit = {},
    onSetSound: (String, String) -> Unit,
    onTestSound: () -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val versionName = try {
        BuildConfig.VERSION_NAME
    } catch (_: Exception) {
        "1.0"
    }

    var currentSubScreen by remember { mutableStateOf(SettingsSubScreen.MAIN) }

    var hasNotificationPermission by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.POST_NOTIFICATIONS
                ) == PackageManager.PERMISSION_GRANTED
            } else {
                true
            }
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasNotificationPermission = granted
        if (granted) {
            Toast.makeText(context, "تم منح صلاحية الإشعارات بنجاح", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "لم يتم منح صلاحية الإشعارات", Toast.LENGTH_SHORT).show()
        }
    }

    val ringtonePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                result.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                result.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            }
            if (uri != null) {
                val ringtone = RingtoneManager.getRingtone(context, uri)
                val title = ringtone?.getTitle(context) ?: "نغمة مخصصة"
                onSetSound(uri.toString(), title)
                Toast.makeText(context, "تم حفظ نغمة التنبيه: $title", Toast.LENGTH_SHORT).show()
            } else {
                onSetSound("", "صامت")
                Toast.makeText(context, "تم ضبط النغمة على الوضع الصامت", Toast.LENGTH_SHORT).show()
            }
        }
    }

    val primaryGreen = Color(0xFF16A34A)
    val lightGreenBg = Color(0xFFF0FDF4)
    val borderGray = Color(0xFFF1F5F9)
    val textPrimary = Color(0xFF0F172A)
    val textSecondary = Color(0xFF64748B)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.92f)
                    .fillMaxHeight(0.85f),
                shape = RoundedCornerShape(24.dp),
                color = Color.White,
                shadowElevation = 6.dp,
                border = BorderStroke(1.dp, Color(0xFFE2E8F0))
            ) {
                Column(
                    modifier = Modifier.padding(20.dp)
                ) {
                    // Header Bar (Fixed at top)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (currentSubScreen != SettingsSubScreen.MAIN) {
                                IconButton(
                                    onClick = { currentSubScreen = SettingsSubScreen.MAIN },
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFF1F5F9))
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                        contentDescription = "رجوع",
                                        tint = textPrimary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                            }
                            Column {
                                Text(
                                    text = when (currentSubScreen) {
                                        SettingsSubScreen.MAIN -> "الإعدادات"
                                        SettingsSubScreen.BACKGROUND_WORK -> "العمل في الخلفية"
                                        SettingsSubScreen.ABOUT_APP -> "حول التطبيق"
                                        SettingsSubScreen.DEVELOPER_RIGHTS -> "حقوق المطور والسياسات"
                                    },
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = textPrimary
                                )
                                if (currentSubScreen == SettingsSubScreen.MAIN) {
                                    Text(
                                        text = "تطبيق واصل - Wi-Fi LAN",
                                        fontSize = 12.sp,
                                        color = textSecondary
                                    )
                                }
                            }
                        }

                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFF1F5F9))
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "إغلاق",
                                tint = textSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    HorizontalDivider(color = borderGray, thickness = 1.dp)
                    Spacer(modifier = Modifier.height(8.dp))

                    // Scrollable Content
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        when (currentSubScreen) {
                            SettingsSubScreen.MAIN -> {
                            // 1. قسم الإشعارات
                            SettingsSectionTitle(title = "قسم الإشعارات")

                            // Item: تفعيل الإشعارات
                            SettingsListItem(
                                icon = Icons.Default.NotificationsActive,
                                iconTint = primaryGreen,
                                iconBg = lightGreenBg,
                                title = "تفعيل الإشعارات",
                                subtitle = "إشعار صوتي عند وصول رسالة جديدة",
                                trailingContent = {
                                    Switch(
                                        checked = notificationsEnabled,
                                        onCheckedChange = onToggleNotifications,
                                        modifier = Modifier.testTag("toggle_notifications_switch"),
                                        colors = SwitchDefaults.colors(
                                            checkedThumbColor = Color.White,
                                            checkedTrackColor = primaryGreen,
                                            uncheckedThumbColor = Color.White,
                                            uncheckedTrackColor = Color(0xFFE2E8F0),
                                            uncheckedBorderColor = Color.Transparent
                                        )
                                    )
                                }
                            )

                            // Permission warning if applicable
                            if (!hasNotificationPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(14.dp),
                                    color = Color(0xFFFEF3C7),
                                    border = BorderStroke(1.dp, Color(0xFFFDE68A))
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Row(
                                            modifier = Modifier.weight(1f),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Warning,
                                                contentDescription = null,
                                                tint = Color(0xFFD97706),
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(
                                                text = "صلاحية الإشعارات غير مفعلة",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF92400E)
                                            )
                                        }
                                        Button(
                                            onClick = { permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                        ) {
                                            Text("تفعيل", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                        }
                                    }
                                }
                            }

                            // Item: نغمة الإشعارات
                            SettingsListItem(
                                icon = Icons.Default.MusicNote,
                                iconTint = primaryGreen,
                                iconBg = lightGreenBg,
                                title = "نغمة الإشعارات",
                                subtitle = soundTitle.ifBlank { "الافتراضية" },
                                testTag = "select_ringtone_button",
                                onClick = {
                                    val currentUri = soundUri.takeIf { it.isNotEmpty() }?.let { Uri.parse(it) }
                                        ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

                                    val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                                        putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_NOTIFICATION)
                                        putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "اختر نغمة الإشعارات")
                                        putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, currentUri)
                                        putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                                        putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
                                    }
                                    ringtonePickerLauncher.launch(intent)
                                },
                                trailingContent = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        IconButton(
                                            onClick = onTestSound,
                                            modifier = Modifier
                                                .size(34.dp)
                                                .clip(CircleShape)
                                                .background(lightGreenBg)
                                                .testTag("test_sound_button")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.VolumeUp,
                                                contentDescription = "استماع للنغمة",
                                                tint = primaryGreen,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Icon(
                                            imageVector = Icons.Default.ChevronLeft,
                                            contentDescription = null,
                                            tint = Color(0xFF94A3B8),
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            // 2. قسم النظام
                            SettingsSectionTitle(title = "قسم النظام")

                            // Item: العمل في الخلفية
                            SettingsListItem(
                                icon = Icons.Default.Settings,
                                iconTint = primaryGreen,
                                iconBg = lightGreenBg,
                                title = "العمل في الخلفية",
                                subtitle = if (persistentBackgroundEnabled) "الخدمة مفعلة - تعمل في الخلفية باستمرار" else "معطلة - انقر للضبط والإلغاء",
                                onClick = { currentSubScreen = SettingsSubScreen.BACKGROUND_WORK }
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            // 3. قسم حول التطبيق
                            SettingsSectionTitle(title = "قسم حول التطبيق")

                            // Item: حول التطبيق
                            SettingsListItem(
                                icon = Icons.Default.Forum,
                                iconTint = primaryGreen,
                                iconBg = lightGreenBg,
                                title = "حول التطبيق",
                                subtitle = "واصل - Wi-Fi LAN (إصدار $versionName)",
                                onClick = { currentSubScreen = SettingsSubScreen.ABOUT_APP }
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            // 4. قسم الدعم
                            SettingsSectionTitle(title = "قسم الدعم")

                            // Item: قناة تيليجرام
                            SettingsListItem(
                                icon = Icons.AutoMirrored.Filled.Send,
                                iconTint = primaryGreen,
                                iconBg = lightGreenBg,
                                title = "قناة تيليجرام",
                                subtitle = "قناة الدعم والتحديثات الرسمية",
                                onClick = {
                                    var opened = false
                                    try {
                                        val telegramIntent = Intent(Intent.ACTION_VIEW, Uri.parse("tg://resolve?domain=MR_Ali_Ios")).apply {
                                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                        }
                                        context.startActivity(telegramIntent)
                                        opened = true
                                    } catch (_: Exception) {
                                        try {
                                            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/MR_Ali_Ios")).apply {
                                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                            }
                                            context.startActivity(browserIntent)
                                            opened = true
                                        } catch (_: Exception) {
                                            opened = false
                                        }
                                    }
                                    if (!opened) {
                                        Toast.makeText(context, "تعذر فتح قناة تيليجرام", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            )

                            // Item: التواصل مع المطور
                            SettingsListItem(
                                icon = Icons.Default.Person,
                                iconTint = primaryGreen,
                                iconBg = lightGreenBg,
                                title = "التواصل مع المطور",
                                subtitle = "الدعم المباشر عبر واتساب",
                                testTag = "whatsapp_contact_button",
                                onClick = {
                                    try {
                                        val whatsappUri = Uri.parse("https://api.whatsapp.com/send?phone=9647810936407")
                                        val intent = Intent(Intent.ACTION_VIEW, whatsappUri).apply {
                                            setPackage("com.whatsapp")
                                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                        }
                                        context.startActivity(intent)
                                    } catch (_: Exception) {
                                        try {
                                            val fallbackUri = Uri.parse("https://wa.me/9647810936407")
                                            val fallbackIntent = Intent(Intent.ACTION_VIEW, fallbackUri).apply {
                                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                            }
                                            context.startActivity(fallbackIntent)
                                        } catch (_: Exception) {
                                            Toast.makeText(context, "تطبيق WhatsApp غير مثبت على هذا الجهاز.", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            // 5. قسم حقوق المطور
                            SettingsSectionTitle(title = "قسم حقوق المطور")

                            // Item: حقوق المطور والسياسات
                            SettingsListItem(
                                icon = Icons.Default.Warning,
                                iconTint = primaryGreen,
                                iconBg = lightGreenBg,
                                title = "حقوق المطور والسياسات",
                                subtitle = "حقوق النشر، شروط الاستخدام، وسياسة الخصوصية",
                                onClick = { currentSubScreen = SettingsSubScreen.DEVELOPER_RIGHTS }
                            )
                        }

                        SettingsSubScreen.BACKGROUND_WORK -> {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                // زر تفعيل/إيقاف التشغيل المستمر في الخلفية
                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    color = Color.White,
                                    border = BorderStroke(1.dp, borderGray)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(16.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = "التشغيل المستمر في الخلفية (Sticky Service)",
                                                fontSize = 15.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = textPrimary
                                            )
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = "إبقاء الخدمة شغالة بوضع الإشعار الدائم لاستقبال الرسائل والمكالمات في الخلفية حتى عند إغلاق التطبيق",
                                                fontSize = 12.sp,
                                                color = textSecondary,
                                                lineHeight = 18.sp
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Switch(
                                            checked = persistentBackgroundEnabled,
                                            onCheckedChange = onTogglePersistentBackground,
                                            modifier = Modifier.testTag("toggle_persistent_bg_switch"),
                                            colors = SwitchDefaults.colors(
                                                checkedThumbColor = Color.White,
                                                checkedTrackColor = primaryGreen,
                                                uncheckedThumbColor = Color.White,
                                                uncheckedTrackColor = Color(0xFFE2E8F0),
                                                uncheckedBorderColor = Color.Transparent
                                            )
                                        )
                                    }
                                }

                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    color = lightGreenBg,
                                    border = BorderStroke(1.dp, Color(0xFFDCFCE7))
                                ) {
                                    Column(
                                        modifier = Modifier.padding(16.dp),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Text(
                                            text = "تعليمات التشغيل في الخلفية",
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = primaryGreen
                                        )
                                        Text(
                                            text = "لضمان بقاء البحث عن الأجهزة واستقبال الرسالات والمكالمات شغالين في الخلفية عند إغلاق الشاشة، يُنصح بإلغاء قيود تقييد البطارية وتفعيل التشغيل التلقائي للتطبيق.",
                                            fontSize = 13.sp,
                                            color = Color(0xFF334155),
                                            lineHeight = 22.sp
                                        )
                                    }
                                }

                                Button(
                                    onClick = {
                                        try {
                                            val intent = Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                                                data = Uri.parse("package:${context.packageName}")
                                            }
                                            context.startActivity(intent)
                                        } catch (_: Exception) {
                                            try {
                                                val fallbackIntent = Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                                                context.startActivity(fallbackIntent)
                                            } catch (_: Exception) {
                                                val appDetailsIntent = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                                    data = Uri.parse("package:${context.packageName}")
                                                }
                                                context.startActivity(appDetailsIntent)
                                            }
                                        }
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(50.dp)
                                        .testTag("battery_settings_button"),
                                    colors = ButtonDefaults.buttonColors(containerColor = primaryGreen),
                                    shape = RoundedCornerShape(14.dp)
                                ) {
                                    Text(
                                        text = "إلغاء قيود البطارية",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }
                        }

                        SettingsSubScreen.ABOUT_APP -> {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                verticalArrangement = Arrangement.spacedBy(14.dp)
                            ) {
                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    color = Color.White,
                                    border = BorderStroke(1.dp, borderGray)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(18.dp),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Box(
                                                modifier = Modifier
                                                    .size(44.dp)
                                                    .clip(RoundedCornerShape(12.dp))
                                                    .background(lightGreenBg),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.Forum,
                                                    contentDescription = null,
                                                    tint = primaryGreen,
                                                    modifier = Modifier.size(24.dp)
                                                )
                                            }
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Column {
                                                Text(
                                                    text = "واصل - Wi-Fi LAN",
                                                    fontSize = 17.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = textPrimary
                                                )
                                                Text(
                                                    text = "الإصدار: $versionName",
                                                    fontSize = 13.sp,
                                                    color = textSecondary
                                                )
                                            }
                                        }

                                        HorizontalDivider(color = borderGray)

                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = lightGreenBg
                                        ) {
                                            Text(
                                                text = "التطبيق مجاني بالكامل",
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = primaryGreen,
                                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                            )
                                        }

                                        Text(
                                            text = "واصل هو تطبيق محادثة واتصال مباشر يعمل عبر شبكة Wi-Fi المحلية (LAN) دون الحاجة للاتصال بالإنترنت. يمنع بيع التطبيق أو إعادة نشره بمقابل مادي.",
                                            fontSize = 13.sp,
                                            color = Color(0xFF334155),
                                            lineHeight = 22.sp
                                        )

                                        Text(
                                            text = "جميع الحقوق محفوظة للمطور Ali © 2026",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = textSecondary
                                        )
                                    }
                                }
                            }
                        }

                        SettingsSubScreen.DEVELOPER_RIGHTS -> {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                RightsItemCard(
                                    title = "حقوق النشر والتأليف",
                                    content = "جميع الحقوق محفوظة لتطبيق واصل © 2026. تم تطوير وبرمجة التطبيق بواسطة Ali."
                                )

                                RightsItemCard(
                                    title = "شروط الاستخدام",
                                    content = "يُسمح بالاستخدام الشخصي والمجاني للتطبيق فقط. يمنع منعاً باتاً تعديل التطبيق، تفكيكه، أو إعادة بيعه أو نشره لمقابل مادي."
                                )

                                RightsItemCard(
                                    title = "سياسة الخصوصية",
                                    content = "حماية الخصوصية هي الأولوية القصوى. تعمل جميع الاتصالات والرسائل داخلياً ضمن الشبكة المحلية (Wi-Fi LAN) فقط. لا يتم استخدام، جمع، أو رفع أي بيانات أو ملفات إلى خوادم خارجية إطلاقاً."
                                )

                                RightsItemCard(
                                    title = "معلومات الترخيص",
                                    content = "ترخيص مجاني مخصص للاتصال عبر الشبكة المحلية (LAN License)."
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
}

@Composable
private fun SettingsListItem(
    icon: ImageVector,
    iconTint: Color = Color(0xFF16A34A),
    iconBg: Color = Color(0xFFF0FDF4),
    title: String,
    subtitle: String? = null,
    testTag: String? = null,
    onClick: (() -> Unit)? = null,
    trailingContent: (@Composable () -> Unit)? = null
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 60.dp)
            .then(
                if (testTag != null) Modifier.testTag(testTag) else Modifier
            )
            .then(
                if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier
            ),
        shape = RoundedCornerShape(16.dp),
        color = Color.White,
        border = BorderStroke(1.dp, Color(0xFFF1F5F9)),
        shadowElevation = 0.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(iconBg),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp,
                            color = Color(0xFF0F172A)
                        )
                    )
                    if (!subtitle.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = subtitle,
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontSize = 12.sp,
                                color = Color(0xFF64748B)
                            ),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
            if (trailingContent != null) {
                Spacer(modifier = Modifier.width(8.dp))
                trailingContent()
            } else if (onClick != null) {
                Spacer(modifier = Modifier.width(8.dp))
                Icon(
                    imageVector = Icons.Default.ChevronLeft,
                    contentDescription = null,
                    tint = Color(0xFF94A3B8),
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@Composable
private fun SettingsSectionTitle(title: String) {
    Text(
        text = title,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        color = Color(0xFF16A34A),
        modifier = Modifier.padding(start = 4.dp, top = 6.dp, bottom = 2.dp)
    )
}

@Composable
private fun RightsItemCard(title: String, content: String) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = Color.White,
        border = BorderStroke(1.dp, Color(0xFFF1F5F9))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F172A)
            )
            Text(
                text = content,
                fontSize = 12.sp,
                color = Color(0xFF475569),
                lineHeight = 20.sp
            )
        }
    }
}

@Composable
fun IncomingConnectionRequestDialog(
    request: ConnectionRequest,
    onAccept: () -> Unit,
    onReject: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onReject,
        containerColor = Color.White,
        titleContentColor = TextPrimary,
        textContentColor = TextSecondary,
        shape = RoundedCornerShape(24.dp),
        icon = {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(WaselGreenContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Smartphone,
                    contentDescription = null,
                    tint = WaselGreenPrimary,
                    modifier = Modifier.size(30.dp)
                )
            }
        },
        title = {
            Text(
                text = "طلب اتصال وارد",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "يرغب ${request.senderName} في الاتصال معك عبر الشبكة المحلية للمحادثة.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = TextSecondary,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    lineHeight = 22.sp
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onAccept,
                colors = ButtonDefaults.buttonColors(containerColor = WaselGreenPrimary),
                shape = RoundedCornerShape(20.dp),
                contentPadding = PaddingValues(horizontal = 24.dp, vertical = 10.dp)
            ) {
                Text("قبول", fontWeight = FontWeight.Bold, color = Color.White)
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onReject,
                shape = RoundedCornerShape(20.dp),
                contentPadding = PaddingValues(horizontal = 20.dp, vertical = 10.dp)
            ) {
                Text("رفض", color = Color(0xFFDC2626), fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
fun OutgoingConnectionRequestDialog(
    device: DeviceDomain,
    onCancel: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onCancel,
        containerColor = Color.White,
        shape = RoundedCornerShape(24.dp),
        icon = {
            CircularProgressIndicator(
                color = WaselGreenPrimary,
                modifier = Modifier.size(40.dp),
                strokeWidth = 3.dp
            )
        },
        title = {
            Text(
                text = "جاري الاتصال...",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "في انتظار موافقة ${device.name} على طلب الاتصال...",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    lineHeight = 20.sp
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = onCancel,
                shape = RoundedCornerShape(16.dp)
            ) {
                Text("إلغاء الطلب", color = Color(0xFFDC2626), fontWeight = FontWeight.Bold)
            }
        }
    )
}
