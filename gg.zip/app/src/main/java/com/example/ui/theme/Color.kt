package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val WaselGreenPrimary = Color(0xFF16A34A)
val WaselGreenSecondary = Color(0xFF15803D)
val WaselGreenContainer = Color(0xFFDCFCE7)
val WaselGreenOnContainer = Color(0xFF14532D)

val DarkBackground = Color(0xFF111827)
val DarkSurface = Color(0xFF1F2937)
val LightBackground = Color(0xFFFAFAFA)
val LightSurface = Color(0xFFFFFFFF)

val TextPrimary = Color(0xFF111827)
val TextSecondary = Color(0xFF6B7280)
val BorderLight = Color(0xFFE5E7EB)

val StatusConnected = Color(0xFF16A34A)
val StatusNearby = Color(0xFF0284C7)
val StatusRequest = Color(0xFFD97706)


